package controller;

import javax.swing.ImageIcon;

/**
 * L'interfaccia Observer definisce i metodi che devono essere implementati da tutte le classi che vogliono essere osservatori
 * di un soggetto.
 * Gli osservatori saranno notificati quando avvengono determinati eventi nel soggetto osservato.
 */
public interface Observer {

	/**
     * Metodo chiamato quando il nickname dell'utente osservato viene aggiornato.
     *
     * @param nickName Il nuovo nickname dell'utente.
     */
    void updateNickname(String nickName);

    /**
     * Metodo chiamato quando l'avatar dell'utente osservato viene aggiornato.
     *
     * @param avatar Il nuovo avatar dell'utente, rappresentato come un'icona.
     */
    void updateAvatar(ImageIcon avatar);

    /**
     * Metodo chiamato quando il livello dell'utente osservato aumenta.
     *
     * @param livello Il nuovo livello dell'utente.
     */
    void levelUp(int livello);

    /**
     * Metodo chiamato quando l'esperienza dell'utente osservato aumenta.
     *
     * @param exp Il nuovo valore di esperienza dell'utente.
     */
    void expUp(int exp);

}
