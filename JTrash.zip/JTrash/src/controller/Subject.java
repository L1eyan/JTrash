package controller;

/**
 * L'interfaccia Subject definisce i metodi per gestire gli osservatori e notificare loro determinati eventi.
 * Le classi che implementano questa interfaccia agiscono come soggetti osservati.
 */
public interface Subject {

	/**
     * Metodo per impostare l'osservatore per il soggetto.
     *
     * @param observer L'osservatore da associare al soggetto.
     */
    void setObserver(Observer observer);

    /**
     * Metodo per notificare agli osservatori che il nickname �� stato aggiornato.
     */
    void notifyNicknameUpdated();

    /**
     * Metodo per notificare agli osservatori che l'avatar �� stato aggiornato.
     */
    void notifyAvatarUpdated();

    /**
     * Metodo per notificare agli osservatori che il livello �� stato incrementato.
     */
    void notifyLevelUp();

    /**
     * Metodo per notificare agli osservatori che l'esperienza �� stata incrementata.
     */
    void notifyExpUp();
     
}
