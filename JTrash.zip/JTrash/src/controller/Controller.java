package controller;

import model.Giocatore;

/**
 * La classe Controller contiene metodi correlati alla gestione degli esiti del gioco.
 */
public class Controller {
	
	/**
	 * Questo metodo viene chiamato quando un giocatore vince una partita.
	 * Aggiorna le statistiche del giocatore, inclusi il numero totale di partite giocate,
	 * il numero totale di partite vinte, i punti esperienza e, se necessario, il livello del giocatore.
	 *
	 * @param player Il giocatore che ha vinto la partita.
	 */
	public static void win(Giocatore player) {
    	
		// Recupero delle statistiche attuali del giocatore
    	int partite = player.getPartite();
		int partiteVinte = player.getPartiteVinte();
		int exp = player.getExp();
		int livello = player.getLivello();
		
		// Incremento delle partite giocate, delle partite vinte e dei punti esperienza
		player.setPartite(partite += 1);
		player.setPartiteVinte(partiteVinte += 1);
		player.setExp(exp += 1);
		
		// Verifica se i punti esperienza corrispondono al livello attuale
		if(exp == player.getLivello()) {
			// Se s��, aumenta il livello del giocatore di 1, e reimposta l'esperienza del giocatore a zero
			player.setLivello(livello += 1);
			player.resetExp();
			
		}
    }
    
	/**
	 * Questo metodo viene chiamato quando un giocatore perde una partita.
	 * Aggiorna il conteggio delle partite giocate e delle partite perse dal giocatore.
	 *
	 * @param player Il giocatore che ha perso la partita.
	 */
    public static void lose(Giocatore player) {
    	
    	// Ottiene il numero di partite giocate dal giocatore
		int partite = player.getPartite();
		 // Ottiene il numero di partite perse dal giocatore
		int partitePerse = player.getPartitePerse();
		
		// Incrementa il numero totale di partite giocate dal giocatore
	    player.setPartite(partite += 1);
	    // Incrementa il numero totale di partite perse dal giocatore
	    player.setPartitePerse(partitePerse += 1);

    }
	
}
