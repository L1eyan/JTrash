package controller;

import javax.swing.ImageIcon;

/**
 * L'interfaccia ProfileChangeListener definisce un metodo di callback per notificare gli listeners
 * quando avviene una modifica del profilo, come ad esempio un cambiamento nel nome utente o nell'avatar.
 */
public interface ProfileChangeListener {
	
    /**
     * Chiamato quando avviene una modifica del profilo, fornendo il nuovo nome utente e l'avatar.
     * Le classi che implementano questa interfaccia dovrebbero gestire l'evento di modifica del profilo in modo appropriato.
     * 
     * @param newUsername Il nuovo nome utente dopo la modifica del profilo.
     * @param avatar Il nuovo avatar dopo la modifica del profilo, rappresentato come ImageIcon.
     */
	void onProfileChanged(String newUsername, ImageIcon avatar);
	
}
