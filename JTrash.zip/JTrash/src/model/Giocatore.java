package model;

import javax.swing.ImageIcon;

import controller.Observer;
import controller.Subject;

/**
 * Questa classe rappresenta un giocatore nel gioco.
 * Implementa l'interfaccia Subject per consentire la notifica degli observer quando lo stato del giocatore cambia.
 */
public class Giocatore implements Subject{
	
	// Dichiarazione dei campi
	private final int initialHandSize = 10;
	private String nickName;
	private int handSize = 10;
	private int partite;
	private int partiteVinte;
	private int partitePerse;
	private int livello = 1;
	private int exp;
	private ImageIcon avatar;
	private Observer observer;
	
    /**
     * Costruttore della classe Giocatore.
     * 
     * @param nickName Il nickname del giocatore
     * @param avatar   L'avatar del giocatore
     */
	public Giocatore(String nickName, ImageIcon avatar) {
		
			this.nickName = nickName;
			this.avatar = avatar;
	}

	/**
	 * Restituisce il nickname del giocatore.
	 * @return Il nickname del giocatore.
	 */
	public String getNickName() {
		return nickName;
	}

	/**
	 * Imposta il nickname del giocatore e notifica gli observer se �� stato modificato.
	 * @param nickName Il nuovo nickname del giocatore.
	 */
	public void setNickName(String nickName) {
		
		if (!this.nickName.equals(nickName)) {
	        this.nickName = nickName;
	        notifyNicknameUpdated();
	    }
	}
	
	/**
	 * Restituisce la dimensione della mano del giocatore.
	 * @return La dimensione della mano del giocatore.
	 */
	public int getHandSize() {
		return handSize;
	}

	/**
	 * Imposta la dimensione della mano del giocatore.
	 * @param handSize La nuova dimensione della mano del giocatore.
	 */
	public void setHandSize(int handSize) {
		this.handSize = handSize;
	}

	/**
	 * Restituisce il numero di partite giocate.
	 * @return Il numero di partite giocate.
	 */
	public int getPartite() {
	    return partite;
	}

	/**
	 * Imposta il numero di partite giocate.
	 * @param partite Il nuovo numero di partite giocate.
	 */
	public void setPartite(int partite) {
	    this.partite = partite;
	}

	/**
	 * Restituisce il numero di partite vinte.
	 * @return Il numero di partite vinte.
	 */
	public int getPartiteVinte() {
	    return partiteVinte;
	}

	/**
	 * Imposta il numero di partite vinte.
	 * @param partiteVinte Il nuovo numero di partite vinte.
	 */
	public void setPartiteVinte(int partiteVinte) {
	    this.partiteVinte = partiteVinte;
	}

	/**
	 * Restituisce il numero di partite perse.
	 * @return Il numero di partite perse.
	 */
	public int getPartitePerse() {
	    return partitePerse;
	}

	/**
	 * Imposta il numero di partite perse.
	 * @param partitePerse Il nuovo numero di partite perse.
	 */
	public void setPartitePerse(int partitePerse) {
	    this.partitePerse = partitePerse;
	}

	/**
	 * Restituisce il livello del giocatore.
	 * @return Il livello del giocatore.
	 */
	public int getLivello() {
	    return livello;
	}

	/**
	 * Imposta il livello del giocatore e notifica l'aggiornamento.
	 * @param livello Il nuovo livello del giocatore.
	 */
	public void setLivello(int livello) {
	    if (this.livello != livello) {
	        this.livello = livello;
	        notifyLevelUp();
	    }
	}

	/**
	 * Restituisce l'avatar del giocatore.
	 * @return L'avatar del giocatore.
	 */
	public ImageIcon getAvatar() {
	    return avatar;
	}

	/**
	 * Imposta l'avatar del giocatore e notifica l'aggiornamento.
	 * @param avatar Il nuovo avatar del giocatore.
	 */
	public void setAvatar(ImageIcon avatar) {
	    if (!this.avatar.equals(avatar)) {
	        this.avatar = avatar;
	        notifyAvatarUpdated();
	    }
	}

	/**
	 * Reimposta la dimensione della mano del giocatore al valore iniziale.
	 * @return La dimensione iniziale della mano del giocatore.
	 */
	public int resetHand() {
	    return initialHandSize;
	}

	/**
	 * Restituisce l'esperienza del giocatore.
	 * @return L'esperienza del giocatore.
	 */
	public int getExp() {
	    return exp;
	}

	/**
	 * Imposta l'esperienza del giocatore e notifica l'aggiornamento.
	 * @param exp La nuova esperienza del giocatore.
	 */
	public void setExp(int exp) {
	    if (this.exp != exp) {
	        this.exp = exp;
	        notifyExpUp();
	    }
	}

	/**
	 * Reimposta l'esperienza del giocatore a 0.
	 */
	public void resetExp() {
	    this.exp = 0;
	}
	
	/**
	 * Imposta l'observer per il giocatore.
	 * @param observer L'observer da impostare.
	 */
	public void setObserver(Observer observer) {
        this.observer = observer;
    }

	/**
	 * Notifica all'observer l'aggiornamento del nickname del giocatore.
	 */
	@Override
	public void notifyNicknameUpdated() {
	    if (observer != null) {
	        observer.updateNickname(getNickName());
	    }
	}

	/**
	 * Notifica all'observer l'aggiornamento dell'avatar del giocatore.
	 */
	public void notifyAvatarUpdated() {
	    if (observer != null) {
	        observer.updateAvatar(getAvatar());
	    }
	}

	/**
	 * Notifica all'observer l'incremento di livello del giocatore.
	 */
	@Override
	public void notifyLevelUp() {
	    if (observer != null) {
	        observer.levelUp(getLivello());
	    }
	}

	/**
	 * Notifica all'observer l'incremento di esperienza del giocatore.
	 */
	@Override
	public void notifyExpUp() {
	    if (observer != null) {
	        observer.expUp(getExp());
	    }
	}
}