package model;

import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * Questa classe gestisce l'audio nel programma.
 * �� implementata come un singleton per garantire un'unica istanza di AudioManager nell'applicazione.
 */
public class AudioManager {
	
	// dichiarazioni di variabili di istanza
    private static AudioManager instance;
    private Clip clip;
    private long clipTimePosition;
    private boolean isPaused = false;
    
    /**
     * Restituisce l'istanza unica di AudioManager.
     * Se non esiste ancora un'istanza, ne crea una nuova.
     * @return L'istanza unica di AudioManager.
     */
    public static AudioManager getInstance() {
        if (instance == null)
            instance = new AudioManager();
        return instance;
    }
    
    /**
     * Costruttore privato per impedire la creazione di istanze esterne di AudioManager.
     */
    private AudioManager() {
    }
    
 
    /**
     * Questo metodo avvia la riproduzione di una clip audio specificata dal nome del file.
     *
     * @param filename Il percorso del file audio da riprodurre.
     */
    public void play(String filename) {
    	
        try {
        	// Crea un oggetto File per rappresentare il file audio specificato dal percorso filename
            File soundFile = new File(filename);
            // Ottiene un AudioInputStream per il file audio utilizzando il metodo statico getAudioInputStream()
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(soundFile);
            // Ottiene un oggetto Clip utilizzando il metodo statico getClip()
            clip = AudioSystem.getClip();
            // Apre il Clip utilizzando l'AudioInputStream ottenuto
            clip.open(audioStream);
            // Avvia la riproduzione della clip audio
            clip.start();
            // Aggiunge un LineListener per gestire gli eventi di fine riproduzione
            clip.addLineListener(new LineListener() {
                @Override
                public void update(LineEvent event) {
                	// Se la riproduzione �� terminata e non �� in pausa, reimposta la posizione di riproduzione a 0 
                	// e riprendi la riproduzione
                    if (event.getType() == LineEvent.Type.STOP && !isPaused) {
                    	clipTimePosition = 0;
                        clip.setMicrosecondPosition(clipTimePosition);
                        clip.start();                    }
                }
            });
            
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
        	// Gestisce eventuali eccezioni stampando lo stack trace
            e.printStackTrace();
        }
    }
    
    /**
     * Mette in pausa la riproduzione della clip audio attualmente in esecuzione.
     * Salva la posizione temporale della clip audio prima di interromperla.
     */
    public void pause() {
    	// Verifica se la clip audio �� in riproduzione e se esiste
        if (clip != null && clip.isRunning()) {
        	// Imposta isPaused a true
        	isPaused = true;
            // Salva la posizione temporale corrente della clip audio
            clipTimePosition = clip.getMicrosecondPosition(); 
            // Interrompe la riproduzione della clip audio
            clip.stop();
        }
    }
    
    /**
     * Riprende la riproduzione della clip audio da dove era stata interrotta.
     * Utilizza la posizione temporale salvata precedentemente durante la pausa.
     */
    public void restart() {
    	 // Verifica se la clip audio esiste e non �� in riproduzione
        if (clip != null && !clip.isRunning()) {
        	// Imposta isPaused a false
        	isPaused = false;
            // Imposta la posizione temporale della clip audio a quella salvata durante la pausa
            clip.setMicrosecondPosition(clipTimePosition); 
            // Riprende la riproduzione della clip audio
            clip.start(); 
        }
    }
}
