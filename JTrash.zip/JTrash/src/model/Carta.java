package model;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JLabel;

/**
 * La classe Carta rappresenta una singola carta di un mazzo da gioco.
 */
public class Carta {
	
	private Rank rank;
	private Suit suit;
	private String imagePath;
	
    /**
     * Costruttore della classe Carta.
     *
     * @param rank Il valore della carta.
     * @param suit Il seme della carta.
     * @param imagePath Il percorso dell'immagine della carta.
     */
	public Carta(Rank rank, Suit suit, String imagePath) {
		this.rank = rank;
		this.suit = suit;
		this.imagePath = imagePath;
	}

	/**
	 * Restituisce il valore (rank) della carta.
	 *
	 * @return Il valore (rank) della carta.
	 */
	public Rank getRank() {
	    return rank;
	}

	/**
	 * Imposta il valore (rank) della carta.
	 *
	 * @param rank Il nuovo valore (rank) della carta da impostare.
	 */
	public void setRank(Rank rank) {
	    this.rank = rank;
	}

	/**
	 * Restituisce il seme della carta.
	 *
	 * @return Il seme della carta.
	 */
	public Suit getSuit() {
	    return suit;
	}

	/**
	 * Imposta il seme della carta.
	 *
	 * @param suit Il nuovo seme della carta da impostare.
	 */
	public void setSuit(Suit suit) {
	    this.suit = suit;
	}

	/**
	 * Genera un mazzo di carte composto da un numero specificato di mazzi.
	 *
	 * @param numberOfDecks Il numero di mazzi da includere nel mazzo combinato.
	 * @return Una lista di carte rappresentanti il mazzo combinato.
	 */
	public static List<Carta> getDeck(int numberOfDecks) {
	    // Inizializza un nuovo mazzo vuoto
	    List<Carta> deck = new ArrayList<>();
	    
	    // Cicla attraverso il numero specificato di mazzi
	    for (int deckNumber = 0; deckNumber < numberOfDecks; deckNumber++) {
	        // Per ogni mazzo, aggiungi tutte le carte per ogni valore e seme
	        for (Rank rank: Rank.values()) {
	            for (Suit suit: Suit.values()){
	                // Costruisci il percorso dell'immagine per la carta
	                String imagePath = "Cards/" + suit + "-" + rank.toInt() + ".jpg";
	                // Aggiungi la carta al mazzo
	                deck.add(new Carta(rank, suit, imagePath));
	            }
	        }
	    }
	    // Restituisci il mazzo combinato
	    return deck;
	}

	/**
	 * Restituisce una stringa che rappresenta l'istanza della carta, includendo il valore del rango e il seme.
	 * 
	 * @return Una stringa che rappresenta l'istanza della carta nel formato "valore_del_rango: seme".
	 */
	@Override
	public String toString() {
		return rank.toInt() + ": " + suit;
	}

	/**
	 * Restituisce il percorso dell'immagine corretto per una carta disegnata in base all'icona associata a una JLabel.
	 * Se l'icona inizia con "CardsResized", viene generato il percorso per le carte ridimensionate.
	 * Se l'icona inizia con "CardsRotatedR", viene generato il percorso per le carte ruotate a destra.
	 *
	 * @param label La JLabel associata all'immagine della carta.
	 * @param drawnCard La carta disegnata.
	 * @return Il percorso dell'immagine della carta corrispondente.
	 */
	public String getImagePath(JLabel label, Carta drawnCard) {
		
		// Se l'icona inizia con "CardsResized", genera il percorso per le carte ridimensionate
		if(label.getIcon().toString().startsWith("CardsResized")) {
			drawnCard.setImagePath("CardsResized/" + drawnCard.getSuit()+ "-" + drawnCard.getRank().toInt() + ".jpg");
		}
		// Se l'icona inizia con "CardsRotatedR", genera il percorso per le carte ruotate
		else if(label.getIcon().toString().startsWith("CardsRotatedR")) {
			drawnCard.setImagePath("CardsRotatedR/" + drawnCard.getSuit()+ "-" + drawnCard.getRank().toInt() + ".jpg");
		}
		// Restituisce il percorso dell'immagine della carta corrispondente
		return imagePath;
		
	}

	/**
	 * Imposta il percorso dell'immagine per la carta.
	 *
	 * @param imagePath Il percorso dell'immagine della carta.
	 */
	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
	
}
