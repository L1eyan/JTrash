package model;

/**
 * L'enumerazione Suit rappresenta i semi delle carte in un mazzo da gioco.
 */
public enum Suit {
	CUORI,
	QUADRI,
	FIORI,
	PICCHE
	
}
