package model;

/**
 * L'enumerazione Rank rappresenta i valori delle carte in un mazzo da gioco.
 */
public enum Rank {
	ASSO(1),
	DUE(2),
	TRE(3),
	QUATTRO(4),
	CINQUE(5),
	SEI(6),
	SETTE(7),
	OTTO(8),
	NOVE(9),
	DIECI(10),
	JACK(11),
	QUEEN(12),
	KING(13);
	
	private int rank;	// Il valore numerico associato al rank
	
	/**
     * Costruttore per l'enumerazione Rank.
     *
     * @param rank Il valore numerico associato al rank.
     */
	Rank(int rank) {
		this.rank = rank;
	}
	
	/**
     * Restituisce il valore numerico associato al rank.
     *
     * @return Il valore numerico del rank.
     */
	public int toInt() {
		return rank;
	}
	
}
