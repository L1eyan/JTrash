package model;

import java.util.Collections;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import controller.Controller;
import view.GameInterface;

/**
 * Questa classe gestisce le regole del gioco.
 */
public class Regole {
	
	private static List<Carta> deck;

	Regole(){
		// Costruttore vuoto
	}
		
	/**
	 * Questo metodo utilizza uno stream per verificare se tutte le carte nella lista di etichette "labels"
	 * non hanno l'icona specificata come dorso della carta "cardBackIcon".
	 * 
	 * @param labels       La lista di etichette delle carte da verificare.
	 * @param cardBackIcon L'icona che rappresenta il dorso delle carte.
	 * @return true se nessuna delle carte nella lista ha l'icona del dorso, altrimenti false.
	 */
    public static boolean areAllCardsNotCardBackIcon(List<JLabel> labels, ImageIcon cardBackIcon) {
        return labels.stream()
                .noneMatch(cardLabel -> cardLabel.getIcon().equals(cardBackIcon));
    }
    
    /**
     * Controlla se il turno deve terminare verificando se tutte le carte del giocatore sono state rivelate.
     * Se il turno del giocatore termina, riduce di uno la dimensione della mano del giocatore.
     * 
     * @param player           Il giocatore attuale.
     * @param playerCardLabels Le etichette delle carte del giocatore.
     * @param cardBackIcon     L'icona che rappresenta il dorso delle carte.
     * @return true se il turno deve terminare, altrimenti false.
     */
    public static boolean checkIfRoundShouldEnd(Giocatore player, List<JLabel> playerCardLabels, ImageIcon cardBackIcon) {
    	// Verifica se tutte le carte del giocatore sono state rivelate
        if (areAllCardsNotCardBackIcon(playerCardLabels, cardBackIcon)) {
        	// Riduce di uno la dimensione della mano del giocatore
        	player.setHandSize(player.getHandSize()-1);
        	// Restituisce true indicando che il turno deve terminare
        	return true;
        }
        // Se non tutte le carte sono state rivelate, il turno continua
        return false;
        
    }
    
    /**
     * Controlla se il gioco deve terminare verificando se uno dei giocatori ha esaurito tutte le carte nella mano.
     * Se il gioco termina, esegue le azioni appropriate in base al vincitore o al perdente.
     * 
     * @param players La lista dei giocatori.
     * @param frame   Il frame principale del gioco.
     * @param player  Il giocatore attuale.
     */
    public static void checkIfGameShouldEnd(List<Giocatore> players, JFrame frame, Giocatore player) {
    	 // Itera attraverso tutti i giocatori nella lista
        for (Giocatore g : players) {
            // Verifica se il giocatore ha esaurito tutte le carte nella mano
            if (g.getHandSize() == 0) {
                // Pulisce il mazzo di carte
                deck.clear();
                // Chiude il frame principale del gioco
                frame.dispose();
                
                // Determina se il giocatore corrente �� il vincitore o il perdente
                if (g.getNickName().equals(player.getNickName())) {
                    // Se il giocatore attuale �� il vincitore, chiama il metodo win del controller
                    Controller.win(player);
                } else {
                    // Se il giocatore attuale �� il perdente, chiama il metodo lose del controller
                    Controller.lose(player);
                }
                
                // Reimposta la dimensione della mano del giocatore
                player.setHandSize(player.resetHand());
                
                // Avvia una nuova interfaccia di gioco con il giocatore attuale
                new GameInterface(player);
                
                // Termina il ciclo
                break;
            }
        }
    }
    
    
    /**
     * Inizializza un mazzo di carte mescolato con il numero specificato di mazzi.
     * 
     * @param numberOfDecks Il numero di mazzi di carte da utilizzare per creare il mazzo iniziale.
     * @return Un mazzo di carte mescolato.
     */
    public static List<Carta> initDeck(int numberOfDecks) {
        // Ottiene un mazzo di carte con il numero specificato di mazzi
        deck = Carta.getDeck(numberOfDecks);
        // Mescola il mazzo di carte
        Collections.shuffle(deck);
        // Restituisce il mazzo inizializzato e mescolato
        return deck;
    }
	
    /**
     * Pesca una carta dal mazzo e la aggiunge alla lista delle carte pescate.
     * Aggiorna le etichette delle carte rimanenti e scartate per riflettere la nuova carta pescata.
     * 
     * @param discardIcon   L'icona che rappresenta la carta scartata.
     * @param remainIcon    L'icona che rappresenta le carte rimanenti nel mazzo.
     * @param drawnList     La lista delle carte pescate.
     * @param discardLabel  L'etichetta che mostra la carta scartata.
     * @param remainLabel   L'etichetta che mostra le carte rimanenti nel mazzo.
     * @param drawnCard     La carta pescata.
     * @return La carta pescata, null se la carta sul retro non �� pi�� presente nel mazzo.
     */
    public static Carta drawCard(ImageIcon discardIcon, ImageIcon remainIcon, List<Carta> drawnList, JLabel discardLabel, 
    								JLabel remainLabel, Carta drawnCard) {
    	 // Verifica se la carta sul retro �� ancora presente (non �� stata ancora pescata)
        if (remainLabel.getIcon() != remainIcon) {
            return null;
        }
        // Pesca la carta dal mazzo
        drawnCard = deck.remove(deck.size() - 1);
        // Aggiunge la carta pescata alla lista delle carte pescate
        drawnList.add(drawnCard);
        // Aggiorna le icone delle etichette per riflettere la nuova carta pescata
        remainLabel.setIcon(new ImageIcon(drawnCard.getImagePath(remainLabel, drawnCard)));
        discardLabel.setIcon(discardIcon);
        return drawnCard;
    }
	
    /**
     * Scarta l'ultima carta pescata dalla lista delle carte pescate.
     * Aggiorna le etichette delle carte rimanenti e scartate per riflettere la carta scartata.
     * 
     * @param drawnList     La lista delle carte pescate.
     * @param lastDrawnCard L'ultima carta pescata.
     * @param discardLabel  L'etichetta che mostra la carta scartata.
     * @param remainLabel   L'etichetta che mostra le carte rimanenti nel mazzo.
     * @param remainIcon    L'icona che rappresenta le carte rimanenti nel mazzo.
     * @return L'ultima carta scartata.
     */
    public static Carta discardCard(List<Carta> drawnList, Carta lastDrawnCard, JLabel discardLabel, JLabel remainLabel, 
    		ImageIcon remainIcon) {
    	// Ottiene l'ultima carta pescata dalla lista delle carte pescate
    	lastDrawnCard = drawnList.get(drawnList.size() - 1);
    	// Aggiorna le icone delle etichette per riflettere la carta scartata e le carte rimanenti nel mazzo
        discardLabel.setIcon(new ImageIcon(lastDrawnCard.getImagePath(discardLabel, lastDrawnCard)));
        remainLabel.setIcon(remainIcon);
        
        return lastDrawnCard;

    }
    
    /**
     * Utilizza la carta pescata su una delle carte del giocatore.
     * 
     * @param labels         La lista delle etichette delle carte del giocatore.
     * @param label          L'etichetta della carta su cui applicare la carta pescata.
     * @param lastDrawnCard  L'ultima carta pescata.
     * @param playerHand     La lista delle carte attualmente in mano al giocatore.
     * @param drawnList      La lista delle carte pescate.
     * @param remainLabel    L'etichetta che mostra le carte rimanenti nel mazzo.
     * @param jokers         La lista dei jolly nel gioco.
     * @param cardBackIcon   L'icona che rappresenta il retro delle carte.
     * @param remainIcon     L'icona che rappresenta le carte rimanenti nel mazzo.
     */
    public static void useDrawnCard(List<JLabel> labels, JLabel label, Carta lastDrawnCard, List<Carta> playerHand, 
		 List<Carta> drawnList, JLabel remainLabel, List<String> jokers, ImageIcon cardBackIcon, ImageIcon remainIcon) {
 	 // Verifica se la carta pescata pu�� essere utilizzata sulla carta cliccata
     if (canUseDrawnCard(labels, label, lastDrawnCard, remainLabel, cardBackIcon, remainIcon, jokers)) {
    	 
         // Ottiene la carta corrispondente dall'insieme di carte del giocatore
         Carta card = playerHand.get(labels.indexOf(label));
         
         // Aggiunge la carta alla lista delle carte pescate
         drawnList.add(card);
      
         // Aggiorna l'icona dell'etichetta della carta cliccata con l'icona della carta pescata
         label.setIcon(new ImageIcon(lastDrawnCard.getImagePath(label, lastDrawnCard)));
    
         // Aggiorna l'icona dell'etichetta della carta rimanente con l'icona della carta giocata
         remainLabel.setIcon(new ImageIcon(card.getImagePath(remainLabel, card)));
        
         // Se l'etichetta corrispondente �� un joker, sostituisci la carta nel set di carte del giocatore
         if (jokers.contains(label.getIcon().toString())) {
             playerHand.set(labels.indexOf(label), new Carta(lastDrawnCard.getRank(), lastDrawnCard.getSuit(), lastDrawnCard.getImagePath(label, lastDrawnCard)));
         }
     }
 }

    /**
     * Verifica se la carta pescata pu�� essere utilizzata su una delle carte del giocatore.
     * 
     * @param labels        La lista delle etichette delle carte del giocatore.
     * @param label         L'etichetta della carta su cui applicare la carta pescata.
     * @param lastDrawnCard L'ultima carta pescata.
     * @param remainLabel   L'etichetta che mostra le carte rimanenti nel mazzo.
     * @param cardBackIcon  L'icona che rappresenta il retro delle carte.
     * @param remainIcon    L'icona che rappresenta le carte rimanenti nel mazzo.
     * @param jokers        La lista dei jolly nel gioco.
     * @return              True se la carta pescata pu�� essere utilizzata, altrimenti false.
     */
	public static boolean canUseDrawnCard(List<JLabel> labels, JLabel label, Carta lastDrawnCard, JLabel remainLabel, 
										ImageIcon cardBackIcon, ImageIcon remainIcon, List<String> jokers) {
		  	
		return ((lastDrawnCard.getRank().toInt() == labels.indexOf(label) + 1 ||
				lastDrawnCard.getRank().toInt() == 11) &&
		   		remainLabel.getIcon() != remainIcon &&
		   		(label.getIcon() == cardBackIcon || 
		   		(jokers.contains(label.getIcon().toString())&& lastDrawnCard.getRank().toInt() != 11)));
	}
	
	/**
	 * Questo metodo permette al giocatore di utilizzare la carta precedentemente scartata su una delle sue carte.
	 * 
	 * @param labels        La lista delle etichette delle carte del giocatore.
	 * @param label         L'etichetta della carta su cui si vuole applicare la carta precedentemente scartata.
	 * @param lastDrawnCard L'ultima carta precedentemente scartata.
	 * @param playerHand    La lista delle carte in mano al giocatore.
	 * @param drawnList     La lista delle carte precedentemente scartate.
	 * @param remainLabel   L'etichetta che mostra le carte rimanenti nel mazzo.
	 * @param discardLabel  L'etichetta che mostra l'ultima carta scartata.
	 * @param discardIcon   L'icona dell'ultima carta scartata.
	 * @param cardBackIcon  L'icona che rappresenta il retro delle carte.
	 * @param remainIcon    L'icona che rappresenta le carte rimanenti nel mazzo.
	 * @param jokers        La lista dei jolly nel gioco.
	 */
    public static void useDiscardedCard(List<JLabel> labels, JLabel label, Carta lastDrawnCard, List<Carta> playerHand, 
    		List<Carta> drawnList, JLabel remainLabel, JLabel discardLabel, ImageIcon discardIcon, ImageIcon cardBackIcon,
    		ImageIcon remainIcon, List<String> jokers) {
    	
    	// Verifica se la carta precedentemente scartata pu�� essere utilizzata sulla carta cliccata
        if (canUseDiscardedCard(labels, label, drawnList, remainLabel, cardBackIcon, remainIcon, jokers)) {

            // Ottiene la carta corrispondente dall'insieme di carte del giocatore
            Carta card = playerHand.get(labels.indexOf(label));

            // Aggiunge la carta alla lista delle carte pescate
            drawnList.add(card);
            
            // Aggiorna l'icona dell'etichetta della carta cliccata con l'icona della carta precedentemente scartata
            label.setIcon(new ImageIcon(lastDrawnCard.getImagePath(label, lastDrawnCard)));

            // Aggiorna l'icona dell'etichetta della carta rimanente con l'icona della carta giocata
            remainLabel.setIcon(new ImageIcon(card.getImagePath(remainLabel, card)));

            // Imposta l'icona dell'etichetta della carta scartata con l'icona dell5o scarto
            discardLabel.setIcon(discardIcon);

            // Se l'etichetta corrispondente �� un joker, sostituisci la carta nel set di carte del giocatore
            if (jokers.contains(label.getIcon().toString())) {
                playerHand.set(labels.indexOf(label), new Carta(lastDrawnCard.getRank(), lastDrawnCard.getSuit(), lastDrawnCard.getImagePath(label, lastDrawnCard)));

            }
            
        }
    }
    
    /**
     * Questo metodo verifica se la carta precedentemente scartata pu�� essere utilizzata sulla carta cliccata dal giocatore.
     * 
     * @param labels       La lista delle etichette delle carte del giocatore.
     * @param label        L'etichetta della carta su cui si vuole applicare la carta precedentemente scartata.
     * @param drawnList    La lista delle carte precedentemente scartate.
     * @param remainLabel  L'etichetta che mostra le carte rimanenti nel mazzo.
     * @param cardBackIcon L'icona che rappresenta il retro delle carte.
     * @param remainIcon   L'icona che rappresenta le carte rimanenti nel mazzo.
     * @param jokers       La lista dei jolly nel gioco.
     * @return true se la carta precedentemente scartata pu�� essere utilizzata sulla carta cliccata, altrimenti false.
     */
    public static boolean canUseDiscardedCard(List<JLabel> labels, JLabel label, List<Carta> drawnList, 
    								JLabel remainLabel, ImageIcon cardBackIcon, ImageIcon remainIcon, List<String> jokers) {
    	
    	return ((drawnList.get(drawnList.size() - 1).getRank().toInt() == labels.indexOf(label) + 1 ||
    			drawnList.get(drawnList.size() - 1).getRank().toInt() == 11) &&
        		remainLabel.getIcon() == remainIcon &&
				(label.getIcon() == cardBackIcon|| 
				(jokers.contains(label.getIcon().toString())&& drawnList.get(drawnList.size() - 1).getRank().toInt() != 11)));
    	
    }	
    
    /**
     * Questo metodo gestisce il click su una carta del giocatore.
     * 
     * @param playerLabels  La lista delle etichette delle carte del giocatore.
     * @param label         L'etichetta della carta cliccata.
     * @param lastDrawnCard L'ultima carta pescata.
     * @param drawnList     La lista delle carte precedentemente pescate.
     * @param playerHand    La mano del giocatore.
     * @param remainLabel   L'etichetta che mostra le carte rimanenti nel mazzo.
     * @param jokers        La lista dei jolly nel gioco.
     * @param cardBackIcon  L'icona che rappresenta il retro delle carte.
     * @param discardLabel  L'etichetta che mostra l'ultima carta scartata.
     * @param discardIcon   L'icona che rappresenta la carta scartata.
     * @param remainIcon    L'icona che rappresenta le carte rimanenti nel mazzo.
     */
    public static void handleCardClick(List<JLabel> playerLabels, JLabel label, Carta lastDrawnCard, List<Carta> drawnList, 
    		List<Carta> playerHand, JLabel remainLabel, List<String> jokers, ImageIcon cardBackIcon, JLabel discardLabel,
    		ImageIcon discardIcon, ImageIcon remainIcon) {
    	// Ottiene l'ultima carta pescata dalla lista delle carte pescate
        lastDrawnCard = drawnList.get(drawnList.size() - 1);
        // Utilizza la carta disegnata, se possibile
        useDrawnCard(playerLabels, label, lastDrawnCard, playerHand, drawnList, remainLabel, jokers, cardBackIcon, remainIcon);
        // Utilizza la carta scartata, se possibile
        useDiscardedCard(playerLabels, label, lastDrawnCard, playerHand, drawnList, remainLabel, discardLabel, discardIcon, cardBackIcon, remainIcon, jokers);

      }
    
    /**
     * Questo metodo gestisce il turno del personaggio non giocante (NPC).
     * 
     * @param npcCardLabels  La lista delle etichette delle carte dell'NPC.
     * @param lastDrawnCard  L'ultima carta pescata.
     * @param jokers          La lista dei jolly nel gioco.
     * @param hand            La mano del NPC.
     * @param discardLabel   L'etichetta che mostra l'ultima carta scartata.
     * @param discardIcon    L'icona che rappresenta la carta scartata.
     * @param drawnList      La lista delle carte precedentemente pescate.
     * @param remainLabel    L'etichetta che mostra le carte rimanenti nel mazzo.
     * @param cardBackIcon   L'icona che rappresenta il retro delle carte.
     * @param remainIcon     L'icona che rappresenta le carte rimanenti nel mazzo.
     * @param drawnCard      La carta appena pescata.
     * @return               True se l'NPC ha giocato una carta, altrimenti false.
     */
    public static boolean npcPlay(List<JLabel> npcCardLabels, Carta lastDrawnCard, List<String> jokers, List<Carta> hand, 
    		JLabel discardLabel, ImageIcon discardIcon, List<Carta> drawnList, JLabel remainLabel, ImageIcon cardBackIcon,
    		ImageIcon remainIcon, Carta drawnCard) {
    	// Prova a utilizzare una carta precedentemente scartata
    	return tryUsingDiscardedCard(npcCardLabels, lastDrawnCard, drawnList, remainLabel, cardBackIcon,
        		jokers, hand, discardLabel, discardIcon, remainIcon);

    }
    
    /**
     * Controlla se la carta precedentemente scartata pu�� essere utilizzata su una delle carte del giocatore NPC.
     * Se una carta pu�� essere utilizzata, la sostituisce nella mano del giocatore NPC con la carta scartata.
     * @param labels La lista delle etichette delle carte del giocatore NPC.
     * @param lastDrawnCard La carta precedentemente scartata.
     * @param drawnList La lista delle carte pescate durante il gioco.
     * @param remainLabel L'etichetta che mostra la carta rimanente nel mazzo.
     * @param cardBackIcon L'icona che rappresenta il retro delle carte.
     * @param jokers La lista delle stringhe che rappresentano le icone delle carte jolly.
     * @param hand La mano attuale del giocatore NPC.
     * @param discardLabel L'etichetta che mostra l'ultima carta scartata.
     * @param discardIcon L'icona che rappresenta una carta scartata.
     * @param remainIcon L'icona che rappresenta una carta rimanente nel mazzo.
     * @return true se una carta precedentemente scartata �� stata giocata con successo, altrimenti false.
     */
    private static boolean tryUsingDiscardedCard(List<JLabel> labels, Carta lastDrawnCard, List<Carta> drawnList, 
    		JLabel remainLabel, ImageIcon cardBackIcon, List<String> jokers, List<Carta> hand, JLabel discardLabel,
    		ImageIcon discardIcon,ImageIcon remainIcon) {
    	// Itera attraverso ogni JLabel nella lista labels
    	for (JLabel l : labels) {
    		// Verifica se la carta precedentemente scartata pu�� essere utilizzata sulla carta del giocatore NPC
    	    if (canUseDiscardedCard(labels, l, drawnList, remainLabel, cardBackIcon, remainIcon, jokers)) {
    	        // Ottiene la carta corrispondente dalla mano del giocatore NPC
    	        Carta card = hand.get(labels.indexOf(l));
    	        // Aggiunge la carta alla lista delle carte pescate
    	        drawnList.add(card);
    	        // Aggiorna l'icona dell'etichetta della carta del giocatore NPC con l'icona della carta precedentemente scartata
    	        l.setIcon(new ImageIcon(lastDrawnCard.getImagePath(l, lastDrawnCard)));
    	        // Se l'etichetta corrispondente �� un jolly, sostituisci la carta nella mano del giocatore NPC
    	        if (jokers.contains(l.getIcon().toString())) {
    	            hand.set(labels.indexOf(l), new Carta(lastDrawnCard.getRank(), lastDrawnCard.getSuit(), lastDrawnCard.getImagePath(l, lastDrawnCard)));
    	        }
    	        // Aggiorna l'icona dell'etichetta della carta rimanente con l'icona della carta giocata
    	        remainLabel.setIcon(new ImageIcon(card.getImagePath(remainLabel, card)));
    	        // Imposta l'icona dell'etichetta della carta scartata con l'icona della carta appena giocata
    	        discardLabel.setIcon(discardIcon);
    	        // Aggiorna l'ultima carta pescata con la carta appena giocata
    	        lastDrawnCard = drawnList.get(drawnList.size() - 1);
    	        return true; // Restituisce true se una carta precedentemente scartata �� stata giocata con successo
    	    }
    	}
    	// Restituisce false se nessuna carta precedentemente scartata pu�� essere giocata
    	return false;
    }
}

	