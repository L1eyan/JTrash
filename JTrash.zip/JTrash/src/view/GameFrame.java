package view;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

/**
 * La classe GameFrame rappresenta la finestra principale del gioco.
 */
public class GameFrame extends JFrame {
	
	/**
     * Costruttore della classe GameFrame.
     * Configura la finestra del gioco con titolo, dimensioni, immagine dell'icona e altre impostazioni.
     */
	GameFrame(){
		
		this.setTitle("JTrash"); // Imposta il titolo della finestra
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Imposta il comportamento di chiusura della finestra
        this.setSize(1280, 720); // Imposta le dimensioni della finestra
        this.setResizable(false); // Impedisce il ridimensionamento della finestra
        this.setLocationRelativeTo(null); // Centra la finestra sullo schermo
        this.setVisible(true); // Rende la finestra visibile
        
        // Imposta l'icona della finestra con un'immagine specificata
        ImageIcon icon = new ImageIcon("Backgrounds/icon.png");
      	this.setIconImage(icon.getImage());
      
	}
}
	
