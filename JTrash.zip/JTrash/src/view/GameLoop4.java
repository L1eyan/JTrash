package view;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

import model.Carta;
import model.Giocatore;
import model.Regole;

/**
 * Questa classe rappresenta il ciclo di gioco che consente di giocare con tre personaggi non giocanti (NPC) 
 * in un gioco di carte.
 * 
 * Estende JPanel per fornire la rappresentazione grafica del gioco e implementa MouseListener 
 * per gestire gli eventi del mouse.
 */
public class GameLoop4 extends JPanel implements MouseListener {
	
	// Dichiarazione delle variabili di istanza
	private GameFrame frame;
	private Image background;
	private ImageIcon cardBackIcon;
	private ImageIcon cardBackIconR;
	private ImageIcon discardIcon;
	private ImageIcon remainIcon;
	private JPanel playerPanel;
	private JPanel npcPanel;
	private JPanel npc2Panel;
	private JPanel npc3Panel;
	private JPanel drawPanel;
	private JLabel discardLabel;
	private JLabel remainLabel;
	private List<Carta> deck;
	private List<Carta> playerHand;
    private List<Carta> npcHand;
    private List<Carta> npc2Hand;
    private List<Carta> npc3Hand;
    private List<Carta> drawnList = new ArrayList<Carta>();
    private List<Giocatore> players = new ArrayList<>();
	private Timer timer;
	private Timer npcTimer;
	private Timer swapTimer;
	private Carta drawnCard;
	private Carta lastDrawnCard;
	private boolean playerRound = true;
	private boolean npcRound = false;
	private boolean npc2Round = false;
	private boolean npc3Round = false;
	private List<JLabel> playerCardLabels = new ArrayList<JLabel>();
	private List<JLabel> npcCardLabels = new ArrayList<JLabel>();
	private List<JLabel> npc2CardLabels = new ArrayList<JLabel>();
	private List<JLabel> npc3CardLabels = new ArrayList<JLabel>();
	private List<String> jokers = new ArrayList<>();
	Giocatore player;
	Giocatore npc;
	Giocatore npc2;
	Giocatore npc3;
	
    /**
     * Costruttore della classe GameLoop4.
     * 
     * @param player Il giocatore umano.
     * @param npc Il primo personaggio non giocante (NPC).
     * @param npc2 Il secondo personaggio non giocante (NPC).
     * @param npc3 Il terzo personaggio non giocante (NPC).
     */
    public GameLoop4(Giocatore player, Giocatore npc, Giocatore npc2, Giocatore npc3) {
    	// Inizializza i giocatori
        this.player = player;
        this.npc = npc;
        this.npc2 = npc2;  
        this.npc3 = npc3;
        
        // Creazione dei componenti GUI
        frame = new GameFrame();
        playerPanel = new JPanel();
        npcPanel = new JPanel();
        npc2Panel = new JPanel(); 
        npc3Panel = new JPanel();  
        drawPanel = new JPanel();
        discardLabel = new JLabel();
        remainLabel = new JLabel();
        
        // Impostazione dell'opacit�� per i pannelli
        playerPanel.setOpaque(false);
        npcPanel.setOpaque(false);
        npc2Panel.setOpaque(false);  
        npc3Panel.setOpaque(false); 
        drawPanel.setOpaque(false);
        
        // Caricamento delle immagini di sfondo e delle icone delle carte
        background = new ImageIcon("Backgrounds/gameBackground.jpg").getImage();
        cardBackIcon = new ImageIcon("CardsResized/puke.jpg");
        cardBackIconR = new ImageIcon("CardsRotatedR/puke.jpg");
        discardIcon = new ImageIcon("CardsResized/discard.jpg");
        remainIcon = new ImageIcon("CardsResized/puke.jpg");
        
        // Aggiunta delle immagini dei joker alla lista
        jokers.add("CardsResized/CUORI-11.jpg");
        jokers.add("CardsResized/FIORI-11.jpg");
        jokers.add("CardsResized/PICCHE-11.jpg");
        jokers.add("CardsResized/QUADRI-11.jpg");
        jokers.add("CardsRotatedR/CUORI-11.jpg");
        jokers.add("CardsRotatedR/FIORI-11.jpg");
        jokers.add("CardsRotatedR/PICCHE-11.jpg");
        jokers.add("CardsRotatedR/QUADRI-11.jpg");

        // Aggiunta dei giocatori alla lista dei giocatori
        players.add(player);
        players.add(npc);
        players.add(npc2);
        players.add(npc3);
        
        // Aggiunta degli ascoltatori degli eventi per le etichette
        remainLabel.addMouseListener(this);
        discardLabel.addMouseListener(this);

        // Impostazione del layout
        frame.setContentPane(this);
        setLayout(new BorderLayout());

        // Aggiunta dei pannelli al frame
        frame.add(playerPanel, BorderLayout.SOUTH);  // playerPanel in basso
        frame.add(npc3Panel, BorderLayout.NORTH);    // npc3Panel in alto
        npcPanel.setLayout(new GridLayout(0, 2));
        frame.add(npcPanel, BorderLayout.EAST);      // npcPanel a destra
        npc2Panel.setLayout(new GridLayout(0, 2));
        frame.add(npc2Panel, BorderLayout.WEST);     // npc2Panel a sinistra
        drawPanel.setLayout(null);
        drawPanel.add(remainLabel);
        drawPanel.add(discardLabel);
        frame.add(drawPanel);

        // Avvio dell'animazione iniziale
        startAnimation(player.getHandSize(), npc.getHandSize(), npc2.getHandSize(), npc3.getHandSize());
    }
    
    
    /**
     * Sovrascrive il metodo paintComponent per disegnare l'immagine di sfondo del pannello.
     * 
     * @param g Il contesto grafico su cui disegnare.
     */
    public void paintComponent(Graphics g) {
    	
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(background, 0, 0, this);
        
    }
    
	/**
	 * Avvia il gioco, gestendo l'estrazione di carte dal mazzo e l'assegnazione
	 * delle carte ai giocatori. Inoltre, gestisce gli eventi del mouse per le carte
	 * dei giocatori durante il proprio turno.
	 */
	private void gameStart() {
		
		// Estrae una carta dal mazzo
		Carta card = deck.remove(deck.size() - 1);
		
		// Crea etichette per le carte dei giocatori
		JLabel playerCardLabel = new JLabel(cardBackIcon);
		JLabel npcCardLabel = new JLabel(cardBackIconR);
		JLabel npc2CardLabel = new JLabel(cardBackIconR);
		JLabel npc3CardLabel = new JLabel(cardBackIcon);
		
		// Se la mano del giocatore non �� piena, assegna la carta al giocatore	
		if (playerHand.size() < player.getHandSize()) {
			
	         playerHand.add(card);
	         playerCardLabels.add(playerCardLabel);
	         playerPanel.add(playerCardLabel);
	         
			}
     
		// Altrimenti, assegna la carta al primo giocatore NPC che ha ancora spazio nella mano  
		else if (npcHand.size() < npc.getHandSize()) {
    	 
	    	 npcHand.add(card);
	    	 npcCardLabels.add(npcCardLabel);
	         npcPanel.add(npcCardLabel);
    
    		}
		// Altrimenti, assegna la carta al secondo giocatore NPC che ha ancora spazio nella mano
		else if (npc2Hand.size() < npc2.getHandSize()) {
    	 
	    	 npc2Hand.add(card);
	    	 npc2CardLabels.add(npc2CardLabel);
	         npc2Panel.add(npc2CardLabel);
         
    		}
		// Altrimenti, assegna la carta al terzo giocatore NPC che ha ancora spazio nella mano	
		else if (npc3Hand.size() < npc3.getHandSize()) {
	    	 
	    	 npc3Hand.add(card);
	    	 npc3CardLabels.add(npc3CardLabel);
	         npc3Panel.add(npc3CardLabel);
        
   		}
		
		// Aggiunge un gestore degli eventi del mouse per la carta del giocatore
	    playerCardLabel.addMouseListener(new MouseAdapter() {
	        @Override
	        public void mousePressed(MouseEvent e) {
	        	// Verifica se �� possibile gestire il clic sulla carta durante il turno del giocatore, ovvero non puoi cliccare
	        	// il cardLabel prima che pesca una carta dal mazzo.
	        	if (drawnList.isEmpty()) {return;}
	        	// Se �� il turno del giocatore, chiama al metodo per gestire l'evento di clic sulla carta del giocatore
	        	if(playerRound) {
	        		Regole.handleCardClick(playerCardLabels, playerCardLabel, lastDrawnCard, drawnList, playerHand, remainLabel,
	        				 jokers, cardBackIcon, discardLabel, discardIcon, remainIcon);
	        		 
	    	        // Verifica se il turno dovrebbe terminare
	    	        if(Regole.checkIfRoundShouldEnd(player, playerCardLabels,cardBackIcon)) {
	    	        	
	    	        	resetGame(player.getHandSize(), npc.getHandSize(), npc2.getHandSize(), npc3.getHandSize());
	    	        } 
	    	        // Verifica se il gioco dovrebbe terminare
	    	        Regole.checkIfGameShouldEnd(players, frame, player);
	    
	        	 }
	        } 	
	   });
	    
	    // Richiede di ricalcolare la disposizione dei componenti GUI  
	    revalidate();

 }
	
	/**
	 * Gestisce l'evento di clic del mouse quando il giocatore preme su una delle etichette di gioco.
	 * Se la carta non �� stata ancora pescata, chiama il metodo drawCard() per pescare una carta.
	 * Se il giocatore preme su "discardLabel" durante il proprio turno e ci sono carte pescate, chiama il metodo discardCard().
	 *
	 * @param e L'evento del mouse generato quando si preme su una componente di gioco.
	 */
	@Override
    public void mousePressed(MouseEvent e) {
    	// Se l'origine dell'evento �� "remainLabel" e non �� stata ancora pescata una carta, pesca una carta.
    	if (e.getSource() == remainLabel && playerRound) {Regole.drawCard(discardIcon, remainIcon, drawnList, discardLabel,
    														remainLabel, drawnCard);} 
    	// Se l'origine dell'evento �� "discardLabel" durante il turno del giocatore e ci sono carte pescate,
		// scarta la carta.
    	else if (e.getSource() == discardLabel && remainLabel.getIcon()!= remainIcon && playerRound) {
    		
    		lastDrawnCard = Regole.discardCard(drawnList, lastDrawnCard, discardLabel, remainLabel, remainIcon);
    		
    		// Passa al turno successivo
            playerRound = false;
            npcRound = true;
            npc2Round = false;
            npc3Round = false;
            
            // Se �� il turno del NPC, chiama il metodo npcAnimation() per consentire al NPC di giocare la propria mossa
            if(npcRound) {npcAnimation(npcCardLabels, npc, npcHand, cardBackIconR);}
        }
    }
    
	/**
	 * Avvia un timer per eseguire l'animazione dello scambio di carte tra giocatori NPC e la carta pescata.
	 *
	 * @param labels   La lista delle etichette delle carte del giocatore NPC coinvolte nello scambio.
	 * @param gamer    Il giocatore NPC coinvolto nello scambio.
	 * @param hand     La mano del giocatore NPC coinvolto nello scambio.
	 * @param backIcon L'icona della carta coperta.
	 */
	private void swapCard(List<JLabel> labels, Giocatore gamer, List<Carta> hand, ImageIcon backIcon) {
		// Inizializza il timer per lo scambio delle carte
        swapTimer = new Timer(1000, e -> {
        	// Indica se �� avvenuto uno scambio
            boolean hasSwapped = false;
            // Ottiene l'ultima carta pescata
            Carta lastDrawnCard = drawnList.get(drawnList.size() - 1);
           
            for (JLabel l : labels) {
                // Verifica se la carta appena pescata pu�� essere utilizzata sulla carta del giocatore NPC
            	if (Regole.canUseDrawnCard(labels, l, lastDrawnCard, remainLabel, backIcon, remainIcon, jokers)) {
            		// Ottiene la carta del giocatore NPC
                    Carta card = hand.get(labels.indexOf(l));
            		System.out.println(lastDrawnCard + "->" + card );
                    drawnList.add(card);
                    l.setIcon(new ImageIcon(lastDrawnCard.getImagePath(l, lastDrawnCard)));
                    // Se l'etichetta corrispondente �� un joker, sostituisci la carta nel set di carte del giocatore NPC
                    if (jokers.contains(l.getIcon().toString())) {
                        hand.set(labels.indexOf(l), new Carta(lastDrawnCard.getRank(), lastDrawnCard.getSuit(), lastDrawnCard.getImagePath(l, lastDrawnCard)));
                    }
                    
                    lastDrawnCard = drawnList.get(drawnList.size() - 1);
                    remainLabel.setIcon(new ImageIcon(card.getImagePath(remainLabel, lastDrawnCard)));
                    discardLabel.setIcon(discardIcon);
                    hasSwapped = true;

                }
            }

            // Se �� avvenuto uno scambio e non tutte le carte sono state rivelate, continua il processo
            if (hasSwapped && !Regole.areAllCardsNotCardBackIcon(labels, backIcon)) {
                // Non fare nulla, continua con il timer
            } else {
            	// Se non �� avvenuto alcuno scambio, scarta la carta e termina il turno
            	Regole.discardCard(drawnList, lastDrawnCard, discardLabel, remainLabel, remainIcon);
            	
            	// Passa al turno successivo in base al giocatore coinvolto nello scambio
            	if(labels == npcCardLabels) {
	            	playerRound = false;
	                npcRound = false;
	                npc2Round = true;
	                npc3Round = false;
            	}
            	
            	else if(labels == npc2CardLabels) {
            		playerRound = false;
	                npcRound = false;
	                npc2Round = false;
	                npc3Round = true;
	                }
            	
            	else if(labels == npc3CardLabels) {
            		playerRound = true;
	                npcRound = false;
	                npc2Round = false;
	                npc3Round = false;
            	}
            	
	            swapTimer.stop();
	            
	            // Verifica se il turno dovrebbe terminare
	            if(Regole.checkIfRoundShouldEnd(gamer, labels, backIcon)){
	            	resetGame(player.getHandSize(), npc.getHandSize(), npc2.getHandSize(), npc3.getHandSize());
		            // Verifica se il gioco dovrebbe terminare
		            Regole.checkIfGameShouldEnd(players, frame, player);
	            	return;
	            	}
	            
	            // Avvia l'animazione del giocatore NPC successivo
	            if (npc2Round) {
	                npcAnimation(npc2CardLabels, npc2, npc2Hand, cardBackIconR);
	            }
	            if (npc3Round) {
	                npcAnimation(npc3CardLabels, npc3, npc3Hand, cardBackIcon);
	            }
            }
        });

        // Avviare il timer
        swapTimer.start();
    }
	
	/**
	 * Avvia un timer per eseguire l'animazione dell'azione del giocatore NPC durante il gioco.
	 *
	 * @param labels   La lista delle etichette delle carte del giocatore NPC coinvolto nell'animazione.
	 * @param gamer    Il giocatore NPC coinvolto nell'animazione.
	 * @param hand     La mano del giocatore NPC coinvolto nell'animazione.
	 * @param backIcon L'icona della carta coperta.
	 */
    private void npcAnimation(List<JLabel> labels, Giocatore gamer, List<Carta> hand, ImageIcon backIcon) {
    	// Inizializza il timer per l'animazione del giocatore NPC
        npcTimer = new Timer(1000, e -> {
            System.out.println("1: " + drawnList.get(drawnList.size() - 1)); // Stampa la carta pescata
            // Verifica se il giocatore NPC ha utilizzato una carta scartata
            boolean hasUsedDiscardedCard = Regole.npcPlay(labels, drawnList.get(drawnList.size() - 1), jokers, hand,
                    discardLabel, discardIcon, drawnList, remainLabel, backIcon, remainIcon, drawnCard);

            // Se il giocatore NPC ha utilizzato una carta scartata
            if (hasUsedDiscardedCard) {
                lastDrawnCard = drawnList.get(drawnList.size() - 1); // Ottiene l'ultima carta pescata
                swapCard(labels, gamer, hand, backIcon); // Avvia lo scambio della carta
            } else {
                lastDrawnCard = Regole.drawCard(discardIcon, remainIcon, drawnList, discardLabel, remainLabel, drawnCard); // Altrimenti, pesca una carta
                swapCard(labels, gamer, hand, backIcon); // E avvia lo scambio della carta
            }

            npcTimer.stop(); // Ferma il timer del giocatore NPC
        });

        npcTimer.start(); // Avvia il timer del giocatore NPC
    }
    
    /**
     * Reimposta lo stato del gioco, rimuovendo tutte le carte dal mazzo e pulendo le mani dei giocatori.
     * 
     * @param playerHandsize La dimensione della mano del giocatore.
     * @param npcHandsize La dimensione della mano del primo giocatore NPC.
     * @param npc2Handsize La dimensione della mano del secondo giocatore NPC.
     * @param npc3Handsize La dimensione della mano del terzo giocatore NPC.
     */
    private void resetGame(int playerHandsize, int npcHandsize, int npc2Handsize, int npc3Handsize) {
    	
    	// Verifica se una delle mani dei giocatori �� vuota
        if (playerHandsize == 0 || npcHandsize == 0 || npc2Handsize == 0 || npc3Handsize == 0) {
            return; // Esce dal metodo se una delle mani �� vuota
        }
        
        // Rimuove tutte le carte dal mazzo
        deck.clear();

        // Pulisce le mani dei giocatori
        playerHand.clear();
        npcHand.clear();
        npc2Hand.clear();
        npc3Hand.clear();
        
        // Rimuove le etichette delle carte dai pannelli dei giocatori
        for (JLabel playerCardLabel : playerCardLabels) {
            playerPanel.remove(playerCardLabel);
        }
        playerCardLabels.clear();

        for (JLabel npcCardLabel : npcCardLabels) {
            npcPanel.remove(npcCardLabel);
        }
        npcCardLabels.clear();
        
        for (JLabel npc2CardLabel : npc2CardLabels) {
            npc2Panel.remove(npc2CardLabel);
        }
        npc2CardLabels.clear();
        
        for (JLabel npc3CardLabel : npc3CardLabels) {
            npc3Panel.remove(npc3CardLabel);
        }
        npc3CardLabels.clear();

        // Pulisce la lista delle carte disegnate e resetta le variabili di stato del gioco
        drawnList.clear();
        playerRound = true;
        npcRound = false;
        npc2Round = false;
        npc3Round = false;

        // Resetta le icone dei pannelli delle carte
        remainLabel.setIcon(null);
        discardLabel.setIcon(null);

        // Avvia l'animazione iniziale con le nuove dimensioni delle mani dei giocatori
        startAnimation(playerHandsize, npcHandsize, npc2Handsize, npc3Handsize);
    }
    
    
    /**
     * Avvia l'animazione iniziale del gioco. Durante questa animazione, vengono inizializzate
     * le mani dei giocatori, il mazzo viene mescolato e viene gestito l'inizio del gioco.
     * Il timer controlla la progressione dell'animazione fino a quando tutte le carte necessarie
     * sono state distribuite ai giocatori. 
     * 
     * @param playerHandSize La dimensione della mano del giocatore.
     * @param npcHandSize La dimensione della mano del primo giocatore NPC.
     * @param npc2HandSize La dimensione della mano del secondo giocatore NPC.
     * @param npc3HandSize La dimensione della mano del terzo giocatore NPC.
     */
    private void startAnimation(int playerHandSize, int npcHandSize, int npc2HandSize, int npc3HandSize) {
    	// Inizializza le mani dei giocatori
        playerHand = new ArrayList<>();
        npcHand = new ArrayList<>();
        npc2Hand = new ArrayList<>();
        npc3Hand = new ArrayList<>();
        
        // Inizializza e mescola il mazzo
        deck = Regole.initDeck(3);
        
        // Crea un timer per gestire l'animazione iniziale
        timer = new Timer(100, e -> {
            // Se ci sono ancora carte nel mazzo da distribuire
            if (deck.size() > 156 - (player.getHandSize() + npc.getHandSize() + npc2.getHandSize() + npc3.getHandSize())) {
                // Inizia il gioco
                gameStart();
            } else {
                // Ferma il timer quando tutte le carte sono state distribuite
                timer.stop();

                // Imposta l'icona della carta coperta e la sua posizione
                remainLabel.setIcon(remainIcon);
                remainLabel.setBounds(325, 135, 105, 150);

                // Imposta l'icona della carta scartata e la sua posizione
                discardLabel.setIcon(discardIcon);
                discardLabel.setBounds(475, 135, 105, 150);
                
                // Stampa le mani dei giocatori NPC per debug
                System.out.println(npcHand);
                System.out.println(npc2Hand);
                System.out.println(npc3Hand);
            }
        });

        // Avvia il timer
        timer.start();
    }
    
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
