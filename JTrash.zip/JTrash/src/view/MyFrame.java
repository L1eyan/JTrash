package view;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

/**
 * Questa rappresenta un frame personalizzato per l'applicazione.
 */
public class MyFrame extends JFrame {
	
	/**
     * Costruttore della classe MyFrame.
     * Imposta le caratteristiche del frame.
     */
	MyFrame(){
		
		// Imposta il titolo del frame
		this.setTitle("JTrash");
        
        // Chiude l'applicazione quando il frame viene chiuso
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Imposta le dimensioni del frame
        this.setSize(512, 512);
        
        // Impedisce il ridimensionamento del frame
        this.setResizable(false);
        
        // Posiziona il frame al centro dello schermo
        this.setLocationRelativeTo(null);
        
        // Rende il frame visibile
        this.setVisible(true);
        
        // Imposta un'icona per il frame
        ImageIcon icon = new ImageIcon("Backgrounds/icon.png");
        this.setIconImage(icon.getImage());
    	
	}
	
	
}
