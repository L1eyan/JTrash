package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.AudioManager;
import model.Giocatore;

/**
 * Questa classe rappresenta la fase di login dell'applicazione.
 * Estende JPanel e implementa ActionListener.
 */
public class LoginPhase extends JPanel implements ActionListener {

	// Dichiarazioni dei componenti dell'interfaccia grafica
    private Image background;
    private Image title;
    private ImageIcon soundIcon;
    private ImageIcon muteIcon;
    private AudioManagerButton soundButton;
    private MyFrame frame;
    private MyButton myButton;
    private JTextField textField;
    private AudioManager audioManager; 

    /**
     * Costruttore della classe LoginPhase.
     * Inizializza l'interfaccia grafica della fase di login.
     */
    public LoginPhase() {
    	// Inizializzazione del frame principale
        frame = new MyFrame();
      
        // Inizializzazione del pulsante di invio e del campo di testo per l'username
        myButton = new MyButton("Submit", this);
        textField = new JTextField();
        audioManager = AudioManager.getInstance();
        soundIcon = new ImageIcon("Avatar/sound.png");
        muteIcon = new ImageIcon("Avatar/mute.png");
        
        // Impostazione delle dimensioni e delle posizioni dei componenti
        myButton.setBounds(200, 280, 100, 40);
        soundButton = new AudioManagerButton(audioManager, soundIcon, muteIcon);
        soundButton.setContentAreaFilled(false);
        soundButton.setBorderPainted(false);
        soundButton.setBounds(390, 370, 128, 128);
        textField.setBounds(150, 200, 200, 40);
        
        // Impostazioni del campo di testo per l'username
        textField.setFont(new Font("Consolas", Font.PLAIN, 25));
        textField.setForeground(new Color(255, 255, 255));
        textField.setBackground(new Color(41, 36, 33));
        textField.setCaretColor(Color.white);
        textField.setText("username");

        // Caricamento delle immagini di sfondo e del titolo
        background = new ImageIcon("Backgrounds/background.png").getImage();
        title = new ImageIcon("Backgrounds/title.png").getImage();
        
        // Impostazione del contenuto del frame principale e aggiunta dei componenti
        frame.setContentPane(this);
        frame.add(myButton);
        frame.add(textField);
        frame.add(soundButton);
        frame.setLayout(null); 
        frame.setVisible(true);
        
        // Riproduzione l'audio di background
        audioManager.play("audio.wav");
        
    }
    
    /**
     * Sovrascrive il metodo paintComponent della superclasse JPanel per disegnare l'interfaccia grafica della fase di login.
     * 
     * @param g L'oggetto Graphics utilizzato per disegnare.
     */
    public void paintComponent(Graphics g) {
    	
    	// Chiamata al metodo paintComponent della superclasse per effettuare il disegno di base del pannello
        super.paintComponent(g);
        
        // Converte l'oggetto Graphics in un oggetto Graphics2D per utilizzare funzionalit�� avanzate di disegno
        Graphics2D g2D = (Graphics2D) g;
        
        // Disegna l'immagine di sfondo alle coordinate (0, 0) del pannello
        g2D.drawImage(background, 0, 0, this);
        
        // Disegna l'immagine del titolo alle coordinate (75, 0) del pannello
        g2D.drawImage(title, 75, 0, this);
    }

    /**
     * Gestisce gli eventi di azione generati dai componenti dell'interfaccia grafica.
     * 
     * @param e L'evento di azione generato.
     */
	@Override
	public void actionPerformed(ActionEvent e) {
		// Ottiene il nickname inserito nel campo di testo
		String nickname = textField.getText();
		// Imposta l'avatar predefinito per il nuovo giocatore
		ImageIcon avatar = new ImageIcon("Avatar/default.png");
		
		// Verifica se l'evento �� stato generato dal pulsante di invio
		if(e.getSource()== myButton) {
			// Crea un nuovo giocatore con il nickname e l'avatar specificati
			Giocatore player = new Giocatore(nickname, avatar);
			// Chiude il frame corrente
			frame.dispose();
			 // Avvia l'interfaccia grafica del gioco con il nuovo giocatore
			new GameInterface(player);
			
		}
	}
}
