package view;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.ProfileChangeListener;
import model.Giocatore;

/**
 * Questa classe rappresenta l'interfaccia per la visualizzazione e la modifica del profilo del giocatore.
 * Estende JPanel e implementa ActionListener.
 */
public class Profilo extends JPanel implements ActionListener{
	
	// Dichiarazioni dei componenti dell'interfaccia grafica
	private ProfileChangeListener profileChangeListener;
	private MyFrame frame;
	private Image background;
	private MyButton reset;
	private JTextField textField;
	private JButton avatarButton;
	private File avatar;
	private ImageIcon newAvatar;
	private JLabel partiteLabel;
	private JLabel partiteVinteLabel;
	private JLabel partitePerseLabel;
	private Giocatore player;
	
	/**
     * Costruttore della classe Profilo.
     * 
     * @param player Il giocatore di cui visualizzare e modificare il profilo.
     * @param profileChangeListener Il listener per il cambio del profilo.
     */
	public Profilo(Giocatore player, ProfileChangeListener profileChangeListener) {
		
		// Inizializzazione delle variabili
		this.player = player;
		this.profileChangeListener = profileChangeListener;
		
		// Inizializzazione del frame
		frame = new MyFrame();
		
		// Creazione dei componenti dell'interfaccia grafica
		reset = new MyButton("Reset", this);
		textField = new JTextField();
		avatarButton = new MyButton("", this);
		partiteLabel = new JLabel();
		partiteVinteLabel = new JLabel();
		partitePerseLabel = new JLabel();
		
		// Impostazione delle posizioni e delle dimensioni dei componenti
		reset.setBounds(200, 280, 100, 40);
		avatarButton.setBounds(180, 50, 128, 128);
		avatarButton.setIcon(player.getAvatar());	
		avatarButton.setContentAreaFilled(false);
		avatarButton.setBorderPainted(false);
		
		textField.setBounds(150, 200, 200, 40);
		textField.setFont(new Font("Consolas",Font.PLAIN, 25));
		textField.setForeground(new Color(255, 255, 255));
		textField.setBackground(new Color(41, 36, 33));
		textField.setCaretColor(Color.white);
		textField.setText(player.getNickName());
		
		partiteLabel.setText("Patite Giocate: " + player.getPartite());
		partiteLabel.setBounds(0, 10, 300, 30);
		partiteLabel.setForeground(new Color(192, 192, 192));
		partiteLabel.setFont(new Font("MV Boli",Font.PLAIN, 20));
		
		partiteVinteLabel.setText("Patite Vinte: " + player.getPartiteVinte());
		partiteVinteLabel.setBounds(0, 40, 300, 30);
		partiteVinteLabel.setForeground(new Color(192, 192, 192));
		partiteVinteLabel.setFont(new Font("MV Boli",Font.PLAIN, 20));

		partitePerseLabel.setText("Patite Perse: " + player.getPartitePerse());
		partitePerseLabel.setBounds(0, 70, 300, 30);
		partitePerseLabel.setForeground(new Color(192, 192, 192));
		partitePerseLabel.setFont(new Font("MV Boli",Font.PLAIN, 20));
		
		// Caricamento dell'immagine di sfondo
		background = new ImageIcon("Backgrounds/background.png").getImage();
		
		// Aggiunta dei componenti al frame
		frame.setContentPane(this);
		frame.add(reset);
		frame.add(avatarButton);
		frame.add(textField);
		frame.add(partiteLabel);
		frame.add(partiteVinteLabel);
		frame.add(partitePerseLabel);
        frame.setLayout(null); 
	}
	
	/**
	 * Sovrascrive il metodo paintComponent della superclasse JPanel per disegnare l'interfaccia grafica del profilo.
	 * 
	 * @param g L'oggetto Graphics utilizzato per disegnare.
	 */
	public void paintComponent(Graphics g) {
    	
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(background, 0, 0, this);
    
    }

	/**
	 * Gestisce gli eventi di azione generati dai componenti dell'interfaccia grafica del profilo.
	 * 
	 * @param e L'evento di azione generato.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// Verifica se l'evento �� stato generato dal pulsante per selezionare l'avatar
		if(e.getSource() == avatarButton) {
			// Crea un selettore di file per selezionare l'avatar
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setCurrentDirectory(new File("."));
			
			// Mostra il selettore di file per selezionare un file
			int response = fileChooser.showOpenDialog(null);
			
			// Se l'utente ha selezionato un file
			if(response == JFileChooser.APPROVE_OPTION) {
				// Ottiene il file selezionato
				avatar = new File(fileChooser.getSelectedFile().getName());
				// Imposta l'icona del pulsante avatar con l'avatar selezionato
				avatarButton.setIcon(new ImageIcon("Avatar/" + avatar));
				
			}
		}
		
		// Verifica se l'evento �� stato generato dal pulsante per il reset del profilo
		if(e.getSource() == reset) {
			// Ottiene il nuovo username inserito nel campo di testo
			String newUsername = textField.getText();
			
			// Se �� stato selezionato un nuovo avatar, lo imposta; altrimenti, mantiene l'avatar attuale
			if(avatar != null) {newAvatar = new ImageIcon("Avatar/" + avatar);}
			else {newAvatar= player.getAvatar();}
			
			// Notifica il listener del cambio del profilo con il nuovo username e l'avatar
			profileChangeListener.onProfileChanged(newUsername, newAvatar);
			
			// Chiude il frame corrente
            frame.dispose();
			
		}
	}
	
}
