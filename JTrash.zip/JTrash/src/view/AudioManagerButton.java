package view;

import javax.swing.ImageIcon;
import javax.swing.JButton;

import model.AudioManager;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * Questa classe rappresenta un pulsante per controllare lo stato dell'audio.
 * Quando viene premuto, alterna tra l'audio attivo e disattivo utilizzando un'istanza di AudioManager.
 */
public class AudioManagerButton extends JButton implements ActionListener {
	
    private AudioManager audioManager;
    private ImageIcon soundIcon;
    private ImageIcon muteIcon;
    
    /**
     * Costruttore della classe AudioManagerButton.
     * 
     * @param audioManager L'oggetto AudioManager che gestisce lo stato dell'audio.
     * @param soundIcon L'icona da visualizzare quando l'audio �� attivo.
     * @param muteIcon L'icona da visualizzare quando l'audio �� disattivo.
     */
    public AudioManagerButton(AudioManager audioManager, ImageIcon soundIcon, ImageIcon muteIcon) {
    	
        this.audioManager = audioManager;
        this.soundIcon = soundIcon;
        this.muteIcon = muteIcon;
        
        // Imposta l'icona iniziale del pulsante all'icona dell'audio attivo
        this.setIcon(soundIcon);
        
        // Aggiunge se stesso come ascoltatore degli eventi di azione (click del pulsante)
        this.addActionListener(this);
        
        // Impedisce al pulsante di ottenere il focus quando viene cliccato
        this.setFocusable(false);
    }

    /**
     * Metodo chiamato quando viene generato un evento di azione, come un clic su questo pulsante.
     *
     * @param e L'evento di azione generato.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
    	// Controlla se l'AudioManager �� nullo e in tal caso esce dal metodo
        if (audioManager == null) return;
        
        // Verifica se l'icona attuale del pulsante �� uguale all'icona dell'audio attivo
        if (getIcon() == soundIcon) {
            // Se s��, mette in pausa l'audio tramite l'AudioManager e imposta l'icona del pulsante all'icona dell'audio disattivo
            audioManager.pause(); 
            setIcon(muteIcon); 
        } else {
            // Se no, riprende l'audio tramite l'AudioManager e imposta l'icona del pulsante all'icona dell'audio attivo
            audioManager.restart(); 
            setIcon(soundIcon); 
        }
    }
}
