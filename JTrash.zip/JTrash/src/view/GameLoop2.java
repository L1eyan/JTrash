package view;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

import model.Carta;
import model.Giocatore;
import model.Regole;

/**
 * Questa classe rappresenta il ciclo di gioco che consente di giocare con un personaggio non giocante (NPC) 
 * in un gioco di carte.
 * 
 * Estende JPanel per fornire la rappresentazione grafica del gioco e implementa MouseListener 
 * per gestire gli eventi del mouse.
 */
public class GameLoop2 extends JPanel implements MouseListener {

	// Dichiarazione delle variabili di istanza
	private GameFrame frame;
	private Image background;
	private ImageIcon cardBackIcon;
	private ImageIcon discardIcon;
	private ImageIcon remainIcon;
	private JPanel playerPanel;
	private JPanel npcPanel;
	private JPanel drawPanel;
	private JLabel discardLabel;
	private JLabel remainLabel;
	private List<Carta> deck;
	private List<Carta> playerHand;
    private List<Carta> npcHand;
    private List<Carta> drawnList = new ArrayList<>();
    private List<Giocatore> players = new ArrayList<>();
	private Timer timer;
	private Timer npcTimer;
	private Timer swapTimer;
	private Carta drawnCard;
	private Carta lastDrawnCard;
	private boolean playerRound = true;
//	private boolean npcRound = false;
	private List<JLabel> playerCardLabels = new ArrayList<JLabel>();
	private List<JLabel> npcCardLabels = new ArrayList<JLabel>();
	private List<String> jokers = new ArrayList<>();
	private Giocatore player;
	private Giocatore npc;
	
	 /**
     * Costruttore della classe GameLoop2.
     * 
     * @param player Il giocatore.
     * @param npc Il personaggio non giocante (NPC).
     */
	public GameLoop2(Giocatore player, Giocatore npc) {
		
		// Inizializzazione dei giocatori
		this.player = player;
		this.npc = npc;
		// Creazione di componenti GUI
	
		frame = new GameFrame();
		playerPanel = new JPanel();
        npcPanel = new JPanel();
        drawPanel = new JPanel();
		discardLabel = new JLabel();
		remainLabel = new JLabel();
		
		// Impostazioni di opacit�� per i pannelli
		playerPanel.setOpaque(false);
		npcPanel.setOpaque(false);
		drawPanel.setOpaque(false);
		
		 // Caricamento delle immagini di sfondo e delle icone delle carte
		background = new ImageIcon("Backgrounds/gameBackground.jpg").getImage();
		cardBackIcon = new ImageIcon("Cards/puke.jpg");
		discardIcon = new ImageIcon("Cards/discard.jpg");
		remainIcon = new ImageIcon("Cards/puke.jpg");
		
		// Aggiunta delle immagini dei joker alla lista
		jokers.add("Cards/CUORI-11.jpg");
		jokers.add("Cards/FIORI-11.jpg");
		jokers.add("Cards/PICCHE-11.jpg");
		jokers.add("Cards/QUADRI-11.jpg");

		players.add(player);
		players.add(npc);
		// Aggiunta di gestori degli eventi per i label
	    remainLabel.addMouseListener(this);
	    discardLabel.addMouseListener(this);
	    
	    // Impostazioni del layout
	    frame.setContentPane(this);
	    frame.setLayout(new BorderLayout());
        frame.add(playerPanel, BorderLayout.SOUTH);
        frame.add(npcPanel, BorderLayout.NORTH);
        drawPanel.setLayout(null);
        drawPanel.add(remainLabel);
        drawPanel.add(discardLabel);
        frame.add(drawPanel);
        
        // Avvio dell'animazione iniziale
        startAnimation(player.getHandSize(), npc.getHandSize());
        
	}
	
	/**
	* Metodo che disegna il componente grafico. Override del metodo
	* paintComponent della classe JPanel.
	*
	* @param g L'oggetto Graphics utilizzato per disegnare il componente.
	*/
	public void paintComponent(Graphics g) {
    	
        super.paintComponent(g);
        Graphics2D g2D = (Graphics2D) g;
        g2D.drawImage(background, 0, 0, this);
        
    }
	
	/**
	 * Avvia il gioco, gestendo l'estrazione di carte dal mazzo e l'assegnazione
	 * delle carte ai giocatori. Inoltre, gestisce gli eventi del mouse per le carte
	 * dei giocatori durante il proprio turno.
	 */
	private void gameStart() {
		
		// Estrae una carta dal mazzo
		Carta card = deck.remove(deck.size() - 1);
		// Crea etichette per le carte dei giocatori
		JLabel playerCardLabel = new JLabel(cardBackIcon);
		JLabel npcCardLabel = new JLabel(cardBackIcon);
	
	 // Se la mano del giocatore non �� piena, assegna la carta al giocatore	
     if (playerHand.size() < player.getHandSize()) {
    	 
         playerHand.add(card);
         playerCardLabels.add(playerCardLabel);
         playerPanel.add(playerCardLabel);
       
    	}
     
     // Altrimenti, assegna la carta al giocatore NPC   
     else if (npcHand.size() < npc.getHandSize()) {
    	 
    	 npcHand.add(card);
    	 npcCardLabels.add(npcCardLabel);
         npcPanel.add(npcCardLabel);
         
    	}
     
     // Aggiunge un gestore degli eventi del mouse per la carta del giocatore
     playerCardLabel.addMouseListener(new MouseAdapter() {
         @Override
         public void mousePressed(MouseEvent e) {     
        	 // Verifica se �� possibile gestire il clic sulla carta durante il turno del giocatore, ovvero non puoi cliccare
        	 // il cardLabel prima che pesca una carta dal mazzo.
        	 if (drawnList.isEmpty()) {return;}
        	 // Se �� il turno del giocatore, chiama al metodo per gestire l'evento di clic sulla carta del giocatore
        	 if(playerRound) {
        		 
        		 Regole.handleCardClick(playerCardLabels, playerCardLabel, lastDrawnCard, drawnList, playerHand, remainLabel,
        				 jokers, cardBackIcon, discardLabel, discardIcon, remainIcon);
        		 
    	         // Verifica se il turno dovrebbe terminare
    	         if(Regole.checkIfRoundShouldEnd(player, playerCardLabels, cardBackIcon)) {
    	        	 resetGame(player.getHandSize(), npc.getHandSize());
    	         } 
    	         // Verifica se il gioco dovrebbe terminare
    	         Regole.checkIfGameShouldEnd(players, frame, player);
        	 }
        } 	
    });

     // Richiede di ricalcolare la disposizione dei componenti GUI
     revalidate();

 }
	
	/**
	 * Gestisce l'evento di clic del mouse quando il giocatore preme su una delle etichette di gioco.
	 * Se la carta non �� stata ancora pescata, chiama il metodo drawCard() per pescare una carta.
	 * Se il giocatore preme su "discardLabel" durante il proprio turno e ci sono carte pescate, chiama il metodo discardCard().
	 *
	 * @param e L'evento del mouse generato quando si preme su una componente di gioco.
	 */
	@Override
    public void mousePressed(MouseEvent e) {
    	// Se l'origine dell'evento �� "remainLabel" e non �� stata ancora pescata una carta, pesca una carta.
    	if (e.getSource() == remainLabel && playerRound) {Regole.drawCard(discardIcon, remainIcon, drawnList, discardLabel,
    														remainLabel, drawnCard);} 
    	// Se l'origine dell'evento �� "discardLabel" durante il turno del giocatore e ci sono carte pescate,
		// scarta la carta.
    	else if (e.getSource() == discardLabel && remainLabel.getIcon()!= remainIcon && playerRound) {
    		
    		lastDrawnCard = Regole.discardCard(drawnList, lastDrawnCard, discardLabel, remainLabel, remainIcon);
    		 // Passa al turno successivo (da giocatore a NPC o viceversa)
            playerRound = !playerRound;
  
            // Chiama il metodo npcAnimation() per consentire al NPC di giocare la propria mossa
            npcAnimation(npcCardLabels, npc);
            
        }}

	/**
	 * Gestisce lo scambio di carte tra la carta appena pescata e le carte del giocatore NPC.
	 * 
	 * @param labels La lista dei label delle carte del giocatore NPC.
	 * @param gamer Il giocatore NPC.
	 */
    private void swapCard(List<JLabel> labels, Giocatore gamer) {
    	// Inizializzazione del timer per controllare il ritmo dello scambio
        swapTimer = new Timer(1000, e -> {
        	// Indica se �� avvenuto uno scambio
        	boolean hasSwapped = false;
        	// Ottiene l'ultima carta pescata
            Carta lastDrawnCard = drawnList.get(drawnList.size() - 1); 
            // Ciclo attraverso i label delle carte del giocatore NPC
            for (JLabel l : labels) {
                // Verifica se la carta appena pescata pu�� essere utilizzata sulla carta del giocatore NPC
            	if (Regole.canUseDrawnCard(labels, l, lastDrawnCard, remainLabel, cardBackIcon, remainIcon, jokers)) {
            		// Ottiene la carta del giocatore NPC corrispondente al label
                    Carta card = npcHand.get(labels.indexOf(l));
                    // Stampa la carta pescata e la carta del giocatore NPC corrispondente
            		System.out.println(lastDrawnCard + "->" + card );
            		// Aggiunge la carta del giocatore NPC alla lista delle carte pescate
                    drawnList.add(card);
                    // Imposta l'icona del label corrispondente alla carta del giocatore NPC con l'icona della carta pescata
                    l.setIcon(new ImageIcon(lastDrawnCard.getImagePath(l, lastDrawnCard)));
                    // Se l'etichetta corrispondente �� un joker, sostituisci la carta nel set di carte del giocatore NPC
                    if (jokers.contains(l.getIcon().toString())) {
                        npcHand.set(labels.indexOf(l), new Carta(lastDrawnCard.getRank(), lastDrawnCard.getSuit(), lastDrawnCard.getImagePath(l, lastDrawnCard)));
                    }
                    
                    // Aggiorna l'ultima carta pescata
                    lastDrawnCard = drawnList.get(drawnList.size() - 1);
                    // Imposta l'icona delle carte rimanenti con l'icona della carta del giocatore NPC
                    remainLabel.setIcon(new ImageIcon(card.getImagePath(remainLabel, lastDrawnCard)));
                    // Imposta l'icona del label della carta scartata con l'icona della carta scartata predefinita
                    discardLabel.setIcon(discardIcon);
                    // Segnala che �� avvenuto uno scambio
                    hasSwapped = true;

                }
            }

            // Se �� avvenuto uno scambio e non tutte le carte sono state rivelate, continua il processo
            if (hasSwapped && !Regole.areAllCardsNotCardBackIcon(labels, cardBackIcon)) {
                // Non fare nulla, continua con il timer
            } else {
            	// Se non �� avvenuto alcuno scambio, scarta la carta e termina il turno
            	Regole.discardCard(drawnList, lastDrawnCard, discardLabel, remainLabel, remainIcon);
            	
            	// Cambia il turno
                playerRound = !playerRound;
                
                // Ferma il timer
                swapTimer.stop();
                
                // Verifica se il turno dovrebbe terminare
                if(Regole.checkIfRoundShouldEnd(gamer, labels, cardBackIcon)){
                    // Reimposta il gioco
                    resetGame(player.getHandSize(), npc.getHandSize());
                    
                    // Verifica se il gioco dovrebbe terminare
                    Regole.checkIfGameShouldEnd(players, frame, player);
                    
                    // Termina il metodo
                    return;
                }
            }
        });

        // Avviare il timer
        swapTimer.start();
    }
    
    /**
     * Gestisce l'animazione del giocatore NPC durante il proprio turno.
     * 
     * @param labels La lista dei label delle carte del giocatore NPC.
     * @param gamer Il giocatore NPC.
     */
    private void npcAnimation(List<JLabel> labels, Giocatore gamer) {
    	// Inizializzazione del timer per controllare il ritmo dell'animazione del giocatore NPC
        npcTimer = new Timer(1000, e -> {
            // Controlla se il giocatore NPC ha utilizzato una carta scartata
            boolean hasUsedDiscardedCard = Regole.npcPlay(labels, lastDrawnCard, jokers, npcHand, discardLabel, discardIcon,
                    drawnList, remainLabel, cardBackIcon, remainIcon, drawnCard);

            // Se il giocatore NPC ha utilizzato una carta scartata, esegui lo scambio di carte
            if (hasUsedDiscardedCard) {
                // Ottiene l'ultima carta pescata
                lastDrawnCard = drawnList.get(drawnList.size() - 1);
                // Esegue lo scambio di carte
                swapCard(labels, gamer);     
            } 
            // Altrimenti, pesca una nuova carta e quindi esegui lo scambio di carte
            else {
                // Pesca una nuova carta e ottiene l'ultima carta pescata
                lastDrawnCard = Regole.drawCard(discardIcon, remainIcon, drawnList, discardLabel, remainLabel, drawnCard);
                // Esegue lo scambio di carte
                swapCard(labels, gamer);
            }

            // Ferma il timer dell'animazione del giocatore NPC
            npcTimer.stop();

        });

        // Avvia il timer dell'animazione del giocatore NPC
        npcTimer.start();
    }

    /**
     * Resetta il gioco dopo la fine di un turno o di una partita, rimuovendo le carte dal mazzo,
     * dai pannelli dei giocatori e dalla lista di carte disegnate. Inoltre, reimposta le variabili
     * di stato e avvia l'animazione iniziale.
     *
     * @param playerHandsize La nuova dimensione della mano del giocatore.
     * @param npcHandsize La nuova dimensione della mano del NPC.
     */
    private void resetGame(int playerHandsize, int npcHandsize) {
    	// Se una delle dimensioni della mano dei giocatori �� 0, esce dalla funzione senza effettuare il reset del gioco
    	if(playerHandsize == 0 || npcHandsize == 0 ) { return;}
    	
    	// Rimuove tutte le carte dal mazzo
        deck.clear();

        // Pulisce le mani dei giocatori
        playerHand.clear();
        npcHand.clear();

        // Rimuove le etichette delle carte dai pannelli dei giocatori
        for (JLabel playerCardLabel : playerCardLabels) {
            playerPanel.remove(playerCardLabel);
        }
        playerCardLabels.clear();

        for (JLabel npcCardLabel : npcCardLabels) {
            npcPanel.remove(npcCardLabel);
        }
        npcCardLabels.clear();

        // Pulisce la lista delle carte disegnate, resetta le variabili di stato
        drawnList.clear();
        playerRound = true;

        // Resetta le icone dei pannelli delle carte
        remainLabel.setIcon(null);
        discardLabel.setIcon(null);

        // Avvia l'animazione iniziale con le nuove dimensioni delle mani dei giocatori
        startAnimation(playerHandsize, npcHandsize);

    }
    
    /**
     * Avvia l'animazione iniziale del gioco. Durante questa animazione, vengono inizializzate
     * le mani dei giocatori, il mazzo viene mescolato e viene gestito l'inizio del gioco.
     * Il timer controlla la progressione dell'animazione fino a quando tutte le carte necessarie
     * sono state distribuite ai giocatori.
     *
     * @param playerHandSize La dimensione iniziale della mano del giocatore.
     * @param npcHandSize La dimensione iniziale della mano del NPC.
     */
    private void startAnimation(int playerHandSize, int npcHandSize) {
    	// Inizializza le mani dei giocatori
        playerHand = new ArrayList<>();
        npcHand = new ArrayList<>();
        
        // Inizializza e mescola il mazzo
        deck = Regole.initDeck(1);
        
        // Crea un timer per gestire l'animazione iniziale
        timer = new Timer(200, e -> {
        	// Controlla se tutti i giocatori ha ottenuto le proprie carte
            if (deck.size() > 52 - (player.getHandSize() + npc.getHandSize())) {
                // Inizia il gioco
                gameStart();
                
            } else {
                // Ferma il timer quando tutte le carte sono state distribuite
                timer.stop();

                // Imposta l'icona della carta coperta e la sua posizione
                remainLabel.setIcon(remainIcon);
                remainLabel.setBounds(500, 100, 105, 150);

                // Imposta l'icona della carta scartata e la sua posizione
                discardLabel.setIcon(discardIcon);
                discardLabel.setBounds(700, 100, 105, 150);
                System.out.println(npcHand);
            }
        });

        // Avvia il timer
        timer.start();
    }

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}