package view;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.*;

import controller.Observer;
import controller.ProfileChangeListener;
import model.AudioManager;
import model.Giocatore;

/**
 * Questa classe rappresenta l'interfaccia grafica del gioco.
 * Estende JPanel e implementa ActionListener, ProfileChangeListener e Observer.
 */
public class GameInterface extends JPanel implements ActionListener, ProfileChangeListener, Observer{
	
	// Dichiarazioni dei componenti dell'interfaccia grafica
	private Image background;
	private ImageIcon avatar;
	private MyButton playWith2;
	private MyButton playWith3;
	private MyButton playWith4;
	private MyButton profile;
	private AudioManagerButton soundButton;
	private MyFrame frame;
	private JLabel usernameLabel;
	private JLabel livelloLabel;
	private JProgressBar bar;
	private Giocatore player;
	private AudioManager audioManager; 
	
	/**
     * Costruttore della classe GameInterface.
     * Inizializza l'interfaccia grafica del gioco.
     * 
     * @param player Il giocatore corrente.
     */
	public GameInterface(Giocatore player){
		
		// Imposta il giocatore corrente e l'Observer per i cambiamenti nel profilo
        this.player = player;
        player.setObserver(this);
        
        // Inizializzazione del gestore dell'audio
        audioManager = AudioManager.getInstance();
        
        // Inizializzazione del frame principale
        frame = new MyFrame();
        
        // Inizializzazione delle etichette per il nickname e il livello del giocatore
        usernameLabel = new JLabel();
        livelloLabel = new JLabel();
        
        // Inizializzazione della barra di avanzamento per l'esperienza del giocatore
        bar = new JProgressBar(0, player.getLivello());
        
        // Inizializzazione dei pulsanti per avviare il gioco con 2, 3 o 4 giocatori
        playWith2 = new MyButton("Play with 2", this);
        playWith3 = new MyButton("Play with 3", this);
        playWith4 = new MyButton("Play with 4", this);
        
        // Inizializzazione del pulsante per visualizzare il profilo del giocatore
        profile = new MyButton("", this);
        profile.setContentAreaFilled(false);
        profile.setBorderPainted(false);
        
        // Inizializzazione del pulsante per il controllo dell'audio
        soundButton = new AudioManagerButton(audioManager, new ImageIcon("Avatar/sound.png"), new ImageIcon("Avatar/mute.png"));
        soundButton.setContentAreaFilled(false);
        soundButton.setBorderPainted(false);
        soundButton.setBounds(390, 370, 128, 128);
        
        // Inizializzazione delle etichette per il nickname e il livello del giocatore
        usernameLabel.setText(player.getNickName());
        usernameLabel.setBounds(140, 0, 300, 150);
        usernameLabel.setForeground(new Color(100, 160, 255));
        usernameLabel.setFont(new Font("MV Boli",Font.PLAIN, 30));
        
        livelloLabel.setText("lv." + player.getLivello());
        livelloLabel.setBounds(145, 0, 50, 200);
        livelloLabel.setForeground(new Color(192, 192, 192));
        livelloLabel.setFont(new Font("Verdana",Font.PLAIN, 15));
        
        // Inizializzazione della barra di avanzamento per l'esperienza del giocatore
        bar.setBounds(145, 110, 150, 20);
        bar.setStringPainted(true);
        bar.setValue(player.getExp());
        bar.setString(player.getExp() + "/"+ (player.getLivello()));
        bar.setForeground(Color.red);
        bar.setBackground(Color.black);

        // Inizializzazione dei pulsanti per avviare il gioco con 2, 3 o 4 giocatori
        playWith2.setBounds(180, 200, 150, 40);
        playWith3.setBounds(180, 250, 150, 40);
        playWith4.setBounds(180, 300, 150, 40);
        
        // Inizializzazione del pulsante per visualizzare il profilo del giocatore
        profile.setBounds(10, 10, 128, 128);

        // Caricamento dell'immagine di sfondo
        background = new ImageIcon("Backgrounds/background.png").getImage();
       
        // Caricamento dell'icona dell'avatar del giocatore
        avatar = player.getAvatar();
        profile.setIcon(avatar);	
        
        // Impostazione del contenuto del frame principale e aggiunta dei componenti
        frame.setContentPane(this);
        frame.add(playWith2);
        frame.add(playWith3);
        frame.add(playWith4);
        frame.add(profile);
        frame.add(soundButton);
        frame.add(usernameLabel);
        frame.add(livelloLabel);
        frame.add(bar);
        frame.setLayout(null); 
    }
	
	/**
	 * Sovrascrive il metodo paintComponent della classe JPanel per disegnare l'immagine di sfondo.
	 * 
	 * @param g L'oggetto Graphics utilizzato per disegnare.
	 */
	@Override
    public void paintComponent(Graphics g) {
		// Chiama il metodo paintComponent della superclasse per eseguire il disegno di base
        super.paintComponent(g);
        // Converte l'oggetto Graphics in Graphics2D per utilizzare funzionalit�� avanzate di disegno
        Graphics2D g2D = (Graphics2D) g;
        // Disegna l'immagine di sfondo nelle coordinate (0, 0).
        // Questo metodo di disegno viene utilizzato per inserire un'immagine all'interno del componente.
        g2D.drawImage(background, 0, 0, this);
    
    }

    /**
     * Gestisce gli eventi di azione generati dai componenti dell'interfaccia utente.
     * 
     * @param e L'evento di azione generato.
     */
	@Override
	public void actionPerformed(ActionEvent e) {
		// Verifica se l'evento �� stato generato dal pulsante "playWith2"
		if (e.getSource() == playWith2) {
			// Chiude la finestra corrente
			frame.dispose();
			// Crea un nuovo giocatore non giocante con un avatar casuale
			Random random = new Random();
			int randomNumber = random.nextInt(8) + 1;
			ImageIcon npcAvatar = new ImageIcon("Avatar/avatar" + randomNumber + ".png");
			Giocatore npc = new Giocatore("npc", npcAvatar);
			// Avvia un nuovo gioco a due giocatori
			new GameLoop2(player, npc);
		}
		// Verifica se l'evento �� stato generato dal pulsante "playWith3"
		else if (e.getSource() == playWith3) {
			
			frame.dispose();
			// Crea due nuovi giocatori non giocanti con avatar casuali
			Random random = new Random();
			int randomNumber = random.nextInt(8) + 1;
			int randomNumber2 = random.nextInt(8) + 1;
			ImageIcon npcAvatar = new ImageIcon("Avatar/avatar" + randomNumber + ".png");
			ImageIcon npcAvatar2 = new ImageIcon("Avatar/avatar" + randomNumber2 + ".png");
			Giocatore npc = new Giocatore("npc", npcAvatar);
			Giocatore npc2 = new Giocatore("npc2", npcAvatar2);
			// Avvia un nuovo gioco a tre giocatori
			new GameLoop3(player, npc, npc2);
		}
		// Verifica se l'evento �� stato generato dal pulsante "playWith4"
		else if (e.getSource() == playWith4) {
			 
			frame.dispose();
			// Crea tre nuovi giocatori non giocanti con avatar casuali
			Random random = new Random();
			int randomNumber = random.nextInt(8) + 1;
			int randomNumber2 = random.nextInt(8) + 1;
			int randomNumber3 = random.nextInt(8) + 1;
			ImageIcon npcAvatar = new ImageIcon("Avatar/avatar" + randomNumber + ".png");
			ImageIcon npcAvatar2 = new ImageIcon("Avatar/avatar" + randomNumber2 + ".png");
			ImageIcon npcAvatar3 = new ImageIcon("Avatar/avatar" + randomNumber3 + ".png");
			Giocatore npc = new Giocatore("npc", npcAvatar);
			Giocatore npc2 = new Giocatore("npc2", npcAvatar2);
			Giocatore npc3 = new Giocatore("npc3", npcAvatar3);
			// Avvia un nuovo gioco a quattro giocatori
			new GameLoop4(player, npc, npc2, npc3);
		}
		
		else if (e.getSource() == profile) {
			
			new Profilo(player, this);
		}
	
	}

	/**
	 * Aggiorna il profilo del giocatore con il nuovo username e l'avatar specificati,
	 * aggiornando di conseguenza l'interfaccia utente.
	 * 
	 * @param newUsername Il nuovo username del giocatore.
	 * @param newAvatar   Il nuovo avatar del giocatore.
	 */
	@Override
	public void onProfileChanged(String newUsername, ImageIcon newAvatar) {
		
		// Aggiorna il testo dell'usernameLabel con il nuovo username del giocatore
	    usernameLabel.setText(newUsername);
	    // Imposta il nuovo username per il giocatore
	    player.setNickName(newUsername);
	    // Aggiorna l'icona del bottone "profile" con il nuovo avatar del giocatore
	    profile.setIcon(newAvatar);
	    // Imposta il nuovo avatar per il giocatore
	    player.setAvatar(newAvatar);
		
	}

	/**
	 * Aggiorna il nickname del giocatore e mostra un messaggio di dialogo
	 * per informare l'utente dell'aggiornamento.
	 * 
	 * @param nickName Il nuovo nickname del giocatore.
	 */
	@Override
	public void updateNickname(String nickName) {
		// Costruisce il messaggio da visualizzare nel dialogo
        String message = "Nickname updated:\n" +
                "New Nickname: " + nickName;
        		 		
        // Utilizza SwingUtilities.invokeLater() per assicurarsi che l'operazione
        // venga eseguita nell'Event Dispatch Thread (EDT) per garantire la
        // sicurezza dei thread e la stabilit�� dell'interfaccia utente.
        SwingUtilities.invokeLater(() -> {
        	// Mostra un dialogo informativo con il messaggio
            JOptionPane.showMessageDialog(this, message, "Nickname Updated", JOptionPane.INFORMATION_MESSAGE);
        });
	}

	/**
	 * Aggiorna l'avatar del giocatore e mostra un messaggio di dialogo
	 * per informare l'utente dell'aggiornamento.
	 * 
	 * @param avatar Il nuovo avatar del giocatore.
	 */
	@Override
	public void updateAvatar(ImageIcon avatar) {

        String message = "Avatar updated:\n" +             
        		"New Avatar: " + avatar;
        		
        SwingUtilities.invokeLater(() -> {
            JOptionPane.showMessageDialog(this, message, "Avatar Updated", JOptionPane.INFORMATION_MESSAGE);
        });
       	
	}
	
	/**
	 * Mostra un dialogo informativo per segnalare l'aumento di livello del giocatore.
	 * 
	 * @param livello Il nuovo livello del giocatore.
	 */
	@Override
	public void levelUp(int livello) {
		
		String message = "Level Up ! \n" +
                "Livello: " + livello;
		
		JOptionPane.showMessageDialog(this, message, "Level Up", JOptionPane.INFORMATION_MESSAGE);
		
	}

	/**
	 * Mostra un dialogo informativo per segnalare l'aumento dell'esperienza del giocatore.
	 * 
	 * @param exp L'esperienza guadagnata dal giocatore.
	 */
	@Override
	public void expUp(int exp) {

		String message = "You win ! \n" +
                "Exp: +" + exp + "\n";
		
		JOptionPane.showMessageDialog(this, message, "Exp Up", JOptionPane.INFORMATION_MESSAGE);
		
	}

	
}