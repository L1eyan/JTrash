package view;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import javax.swing.JButton;

/**
 * Questa rappresenta un bottone personalizzato per l'applicazione.
 */
public class MyButton extends JButton {
	
	/**
     * Costruttore per inizializzare il pulsante personalizzato.
     *
     * @param text           Il testo da visualizzare sul pulsante.
     * @param actionListener L'ActionListener per gestire i clic del pulsante.
     */
	public MyButton(String text, ActionListener actionListener){
	
		// Imposta il pulsante in modo che non possa essere selezionato tramite il tab
		this.setFocusable(false);

		// Imposta il testo del pulsante
		this.setText(text);

		// Imposta la posizione orizzontale del testo al centro del pulsante
		this.setHorizontalTextPosition(JButton.CENTER);

		// Imposta la posizione verticale del testo al centro del pulsante
		this.setVerticalTextPosition(JButton.CENTER);

		// Imposta il tipo di carattere del testo del pulsante
		this.setFont(new Font("MV Boli", Font.BOLD, 18));

		// Imposta il colore del testo del pulsante
		this.setForeground(new Color(123, 50, 250));

		// Imposta il colore dello sfondo del pulsante
		this.setBackground(new Color(41, 36, 33));

		// Aggiunge un ActionListener per gestire i clic sul pulsante
		this.addActionListener(actionListener);
	}
}
