package view;

/**
 * Questa classe rappresenta il punto di ingresso dell'applicazione.
 * Avvia l'applicazione creando un'istanza della classe LoginPhase.
 */
public class JTrash {

	public static void main(String[] args) {
		// Crea un'istanza della classe LoginPhase per avviare l'applicazione
		new LoginPhase();

	}
}
	